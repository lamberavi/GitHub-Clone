import React from 'react';
import { GitCommit, FolderPlus, Star, Edit, Loader2 } from 'lucide-react';

export default function ActivitySection({ activities = [], loading = false }) {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-12 text-[#8b949e]">
        <Loader2 className="w-6 h-6 animate-spin text-[#58a6ff]" />
      </div>
    );
  }

  if (activities.length === 0) {
    return (
      <div className="text-center py-10 border border-[#30363d]/50 bg-[#161b22]/20 rounded-xl">
        <p className="text-xs font-semibold text-[#8b949e]">No recent activity logs recorded.</p>
      </div>
    );
  }

  const getActivityIcon = (type) => {
    switch (type) {
      case 'commit':
        return <GitCommit size={14} className="text-emerald-400" />;
      case 'repo_created':
        return <FolderPlus size={14} className="text-blue-400" />;
      case 'starred':
        return <Star size={14} className="text-amber-400" />;
      case 'profile_update':
      default:
        return <Edit size={14} className="text-purple-400" />;
    }
  };

  return (
    <div className="space-y-4 select-none">
      <h3 className="text-xs font-black uppercase tracking-wider text-[#8b949e]">Contribution Activity</h3>
      
      <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#30363d]">
        {activities.map((act, idx) => (
          <div key={idx} className="relative flex items-start gap-3 group">
            <div className="absolute -left-6 top-0.5 p-1 bg-[#0d1117] border border-[#30363d] rounded-full z-10">
              {getActivityIcon(act.activityType)}
            </div>
            
            <div className="glass-panel p-3.5 rounded-xl border border-[#30363d]/60 hover:border-[#58a6ff]/40 transition-colors w-full space-y-1">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-white">
                  {act.activityType === 'repo_created' && `Created repository ${act.repository}`}
                  {act.activityType === 'commit' && `Committed to ${act.repository}`}
                  {act.activityType === 'starred' && `Starred ${act.repository}`}
                  {act.activityType === 'profile_update' && `Updated profile settings`}
                </span>
                <span className="text-[10px] text-[#8b949e]">
                  {new Date(act.createdAt).toLocaleDateString()}
                </span>
              </div>
              <p className="text-xs text-[#8b949e] font-semibold">{act.details}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
