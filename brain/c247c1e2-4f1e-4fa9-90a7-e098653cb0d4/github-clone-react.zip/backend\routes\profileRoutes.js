import express from 'express';
import mongoose from 'mongoose';
import User from '../models/User.js';
import Repository from '../models/Repository.js';
import Contribution from '../models/Contribution.js';
import Activity from '../models/Activity.js';
import protect from '../middleware/authMiddleware.js';

const router = express.Router();

// Helper: Check connection state
const isDbConnected = () => mongoose.connection.readyState === 1;

// In-Memory Database fallback collections for offline developer mode
let mockUsers = [
  {
    uid: 'mock_uid_dev',
    username: 'ravil',
    firstName: 'Ravil',
    lastName: 'Developer',
    email: 'ravil@antigravity.io',
    bio: 'Full Stack Engineer & OSS Enthusiast. Building antigravity apps 🚀',
    company: 'Antigravity Labs',
    location: 'Bangalore, India',
    website: 'https://antigravity.io',
    followers: 1240,
    following: 382,
    role: 'admin',
    isVerified: true
  }
];

let mockRepositories = [
  {
    repoId: 'github-clone-react',
    ownerId: 'mock_uid_dev',
    repoName: 'github-clone-react',
    description: 'A premium client-side GitHub clone built with React, Vite, Tailwind CSS, and Monaco Editor.',
    visibility: 'public',
    language: 'JavaScript',
    stars: 284,
    forks: 43,
    watchers: 15,
    openIssues: 2,
    defaultBranch: 'main',
    hasReadme: true,
    hasGitignore: true,
    license: 'MIT',
    isPinned: true,
    isArchived: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

let mockContributions = [];
let mockActivities = [
  {
    uid: 'mock_uid_dev',
    activityType: 'repo_created',
    repository: 'github-clone-react',
    details: 'Initial workspace scaffolded successfully.',
    createdAt: new Date().toISOString()
  }
];

// Helper: Format Date
const getTodayDateString = () => {
  return new Date().toISOString().split('T')[0];
};

// @desc    Get user profile data ONLY
// @route   GET /api/profile/:username
// @access  Public
router.get('/:username', async (req, res) => {
  const startTime = Date.now();
  try {
    const { username } = req.params;

    let userObj = null;

    if (!isDbConnected()) {
      userObj = mockUsers.find(u => u.username === username);
      if (!userObj) {
        userObj = mockUsers[0];
      }
    } else {
      userObj = await User.findOne({ username });
    }

    if (!userObj) {
      return res.status(404).json({ message: `User not found: @${username}` });
    }

    res.status(200).json({ success: true, user: userObj });
  } catch (error) {
    res.status(500).json({ message: `Profile Fetch Error: ${error.message}` });
  }
});

// @desc    Get user repositories ONLY
// @route   GET /api/profile/:username/repos
// @access  Public
router.get('/:username/repos', async (req, res) => {
  try {
    const { username } = req.params;
    let repos = [];

    if (!isDbConnected()) {
      const userObj = mockUsers.find(u => u.username === username) || mockUsers[0];
      repos = mockRepositories.filter(r => r.ownerId === userObj.uid);
    } else {
      const userObj = await User.findOne({ username });
      if (userObj) {
        repos = await Repository.find({ ownerId: userObj.uid }).sort({ updatedAt: -1 });
      }
    }

    res.status(200).json({ success: true, repositories: repos });
  } catch (error) {
    res.status(500).json({ message: `Repos Fetch Error: ${error.message}` });
  }
});

// @desc    Get user profile statistics ONLY
// @route   GET /api/profile/:username/stats
// @access  Public
router.get('/:username/stats', async (req, res) => {
  try {
    const { username } = req.params;
    let repoCount = 0;
    let starCount = 0;
    let commitCount = 0;
    let langCount = 0;

    if (!isDbConnected()) {
      const userObj = mockUsers.find(u => u.username === username) || mockUsers[0];
      const repos = mockRepositories.filter(r => r.ownerId === userObj.uid);
      repoCount = repos.length;
      starCount = repos.reduce((acc, curr) => acc + curr.stars, 0);
      commitCount = mockContributions.filter(c => c.uid === userObj.uid).reduce((acc, curr) => acc + curr.commitCount, 0);
      langCount = [...new Set(repos.map(r => r.language))].length;
    } else {
      const userObj = await User.findOne({ username });
      if (userObj) {
        const repos = await Repository.find({ ownerId: userObj.uid });
        repoCount = repos.length;
        starCount = repos.reduce((acc, curr) => acc + curr.stars, 0);
        
        const contributions = await Contribution.find({ uid: userObj.uid });
        commitCount = contributions.reduce((acc, curr) => acc + curr.commitCount, 0);
        
        langCount = [...new Set(repos.map(r => r.language).filter(Boolean))].length;
      }
    }

    res.status(200).json({
      success: true,
      stats: {
        repositories: repoCount,
        commits: commitCount,
        stars: starCount,
        languages: langCount
      }
    });
  } catch (error) {
    res.status(500).json({ message: `Stats Fetch Error: ${error.message}` });
  }
});

// @desc    Get user contributions ONLY
// @route   GET /api/profile/:username/contributions
// @access  Public
router.get('/:username/contributions', async (req, res) => {
  try {
    const { username } = req.params;
    let contribs = [];

    if (!isDbConnected()) {
      const userObj = mockUsers.find(u => u.username === username) || mockUsers[0];
      contribs = mockContributions.filter(c => c.uid === userObj.uid);
    } else {
      const userObj = await User.findOne({ username });
      if (userObj) {
        contribs = await Contribution.find({ uid: userObj.uid });
      }
    }

    res.status(200).json({ success: true, contributions: contribs });
  } catch (error) {
    res.status(500).json({ message: `Contributions Fetch Error: ${error.message}` });
  }
});

// @desc    Get user activity feed ONLY
// @route   GET /api/profile/:username/activity
// @access  Public
router.get('/:username/activity', async (req, res) => {
  try {
    const { username } = req.params;
    let acts = [];

    if (!isDbConnected()) {
      const userObj = mockUsers.find(u => u.username === username) || mockUsers[0];
      acts = mockActivities.filter(a => a.uid === userObj.uid);
    } else {
      const userObj = await User.findOne({ username });
      if (userObj) {
        acts = await Activity.find({ uid: userObj.uid }).sort({ createdAt: -1 }).limit(20);
      }
    }

    res.status(200).json({ success: true, activities: acts });
  } catch (error) {
    res.status(500).json({ message: `Activity Fetch Error: ${error.message}` });
  }
});

// @desc    Update user profile meta information
// @route   PUT /api/profile/update
// @access  Private
router.put('/update', protect, async (req, res) => {
  try {
    let userObj = null;

    if (!isDbConnected()) {
      userObj = mockUsers.find(u => u.uid === req.user.uid || u.email === req.user.email) || mockUsers[0];
      userObj.firstName = req.body.firstName || userObj.firstName;
      userObj.lastName = req.body.lastName || userObj.lastName;
      userObj.bio = req.body.bio !== undefined ? req.body.bio : userObj.bio;
      userObj.company = req.body.company !== undefined ? req.body.company : userObj.company;
      userObj.location = req.body.location !== undefined ? req.body.location : userObj.location;
      userObj.website = req.body.website !== undefined ? req.body.website : userObj.website;

      mockActivities.push({
        uid: userObj.uid,
        activityType: 'profile_update',
        details: 'Updated account biography and contact profile details.',
        createdAt: new Date().toISOString()
      });
    } else {
      const user = await User.findById(req.user.id);
      if (!user) {
        return res.status(404).json({ message: 'User session not found' });
      }

      user.firstName = req.body.firstName || user.firstName;
      user.lastName = req.body.lastName || user.lastName;
      user.bio = req.body.bio !== undefined ? req.body.bio : user.bio;
      user.company = req.body.company !== undefined ? req.body.company : user.company;
      user.location = req.body.location !== undefined ? req.body.location : user.location;
      user.website = req.body.website !== undefined ? req.body.website : user.website;

      if (req.body.skills) user.skills = req.body.skills;
      if (req.body.socialLinks) user.socialLinks = req.body.socialLinks;

      await user.save();
      userObj = user;

      await Activity.create({
        uid: user.uid,
        activityType: 'profile_update',
        details: 'Updated account biography and contact profile details.'
      });
    }

    res.status(200).json({
      success: true,
      user: userObj
    });
  } catch (error) {
    res.status(500).json({ message: `Profile Update Error: ${error.message}` });
  }
});

// @desc    Create a new repository
// @route   POST /api/profile/repos/create
// @access  Private
router.post('/repos/create', protect, async (req, res) => {
  try {
    const { repoName, description, visibility, language, hasReadme, hasGitignore, license } = req.body;

    if (!repoName) {
      return res.status(400).json({ message: 'Repository name is required' });
    }

    // Name validations (alphanumeric, periods, hyphens, underscores)
    const nameRegex = /^[a-zA-Z0-9._-]+$/;
    if (!nameRegex.test(repoName)) {
      return res.status(400).json({ message: 'Repository name can only contain alphanumeric characters, hyphens, periods, and underscores.' });
    }

    let userObj = null;
    let repo = null;

    const cleanId = repoName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    
    if (!isDbConnected()) {
      userObj = mockUsers[0];
      const repoId = `${userObj.username}-${cleanId}`;
      
      repo = {
        repoId,
        ownerId: userObj.uid,
        repoName,
        description: description || '',
        visibility: visibility || 'public',
        language: language || 'JavaScript',
        stars: 0,
        forks: 0,
        watchers: 1,
        openIssues: 0,
        defaultBranch: 'main',
        hasReadme: !!hasReadme,
        hasGitignore: !!hasGitignore,
        license: license || 'None',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      mockRepositories.unshift(repo);
      mockActivities.push({
        uid: userObj.uid,
        activityType: 'repo_created',
        repository: repoName,
        details: `Scaffolded a new ${visibility} repository with default main branch.`,
        createdAt: new Date().toISOString()
      });
    } else {
      const user = await User.findById(req.user.id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      userObj = user;
      const repoId = `${user.username}-${cleanId}`;

      const existingRepo = await Repository.findOne({ repoId });
      if (existingRepo) {
        return res.status(400).json({ message: 'A repository with this name already exists.' });
      }

      repo = await Repository.create({
        repoId,
        ownerId: user.uid,
        repoName,
        description: description || '',
        visibility: visibility || 'public',
        language: language || 'JavaScript',
        hasReadme: !!hasReadme,
        hasGitignore: !!hasGitignore,
        license: license || 'None',
        defaultBranch: 'main'
      });

      await Activity.create({
        uid: user.uid,
        activityType: 'repo_created',
        repository: repoName,
        details: `Scaffolded a new ${visibility} repository with default main branch.`
      });
    }

    res.status(201).json({
      success: true,
      repository: repo
    });
  } catch (error) {
    res.status(500).json({ message: `Repository Creation Error: ${error.message}` });
  }
});

// @desc    Edit/Rename an existing repository
// @route   PUT /api/profile/repos/:repoId
// @access  Private
router.put('/repos/:repoId', protect, async (req, res) => {
  try {
    const { repoId } = req.params;
    const { repoName, description, visibility, language } = req.body;

    let repo = null;

    if (!isDbConnected()) {
      repo = mockRepositories.find(r => r.repoId === repoId);
      if (!repo) {
        return res.status(404).json({ message: 'Repository not found' });
      }

      if (repoName && repoName !== repo.repoName) {
        const cleanId = repoName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
        repo.repoId = `${mockUsers[0].username}-${cleanId}`;
        repo.repoName = repoName;
      }
      if (description !== undefined) repo.description = description;
      if (visibility !== undefined) repo.visibility = visibility;
      if (language !== undefined) repo.language = language;
      repo.updatedAt = new Date().toISOString();

      mockActivities.push({
        uid: mockUsers[0].uid,
        activityType: 'profile_update',
        details: `Updated metadata for repository: ${repo.repoName}.`,
        createdAt: new Date().toISOString()
      });
    } else {
      const user = await User.findById(req.user.id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      repo = await Repository.findOne({ repoId });
      if (!repo) {
        return res.status(404).json({ message: 'Repository not found' });
      }

      if (repo.ownerId !== user.uid) {
        return res.status(403).json({ message: 'Unauthorized repository access' });
      }

      if (repoName && repoName !== repo.repoName) {
        const cleanId = repoName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
        const newRepoId = `${user.username}-${cleanId}`;

        const duplicate = await Repository.findOne({ repoId: newRepoId });
        if (duplicate && duplicate._id.toString() !== repo._id.toString()) {
          return res.status(400).json({ message: 'A repository with this name already exists.' });
        }

        repo.repoName = repoName;
        repo.repoId = newRepoId;
      }

      if (description !== undefined) repo.description = description;
      if (visibility !== undefined) repo.visibility = visibility;
      if (language !== undefined) repo.language = language;

      await repo.save();

      await Activity.create({
        uid: user.uid,
        activityType: 'profile_update',
        details: `Updated metadata for repository: ${repo.repoName}.`
      });
    }

    res.status(200).json({
      success: true,
      repository: repo
    });
  } catch (error) {
    res.status(500).json({ message: `Repository Edit Error: ${error.message}` });
  }
});

// @desc    Delete a repository
// @route   DELETE /api/profile/repos/:repoId
// @access  Private
router.delete('/repos/:repoId', protect, async (req, res) => {
  try {
    const { repoId } = req.params;

    if (!isDbConnected()) {
      const index = mockRepositories.findIndex(r => r.repoId === repoId);
      if (index === -1) {
        return res.status(404).json({ message: 'Repository not found' });
      }
      const repo = mockRepositories[index];
      mockRepositories.splice(index, 1);

      mockActivities.push({
        uid: mockUsers[0].uid,
        activityType: 'profile_update',
        details: `Deleted the repository: ${repo.repoName}.`,
        createdAt: new Date().toISOString()
      });
    } else {
      const user = await User.findById(req.user.id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      const repo = await Repository.findOne({ repoId });
      if (!repo) {
        return res.status(404).json({ message: 'Repository not found' });
      }

      if (repo.ownerId !== user.uid) {
        return res.status(403).json({ message: 'Unauthorized repository access' });
      }

      await Repository.deleteOne({ repoId });

      await Activity.create({
        uid: user.uid,
        activityType: 'profile_update',
        details: `Deleted the repository: ${repo.repoName}.`
      });
    }

    res.status(200).json({
      success: true,
      message: 'Repository deleted successfully.'
    });
  } catch (error) {
    res.status(500).json({ message: `Repository Deletion Error: ${error.message}` });
  }
});

// @desc    Toggle pin status for a repository
// @route   POST /api/profile/repos/pin
// @access  Private
router.post('/repos/pin', protect, async (req, res) => {
  try {
    const { repoId } = req.body;
    let repo = null;

    if (!isDbConnected()) {
      repo = mockRepositories.find(r => r.repoId === repoId);
      if (repo) {
        repo.isPinned = !repo.isPinned;
      }
    } else {
      repo = await Repository.findOne({ repoId });
      if (repo) {
        repo.isPinned = !repo.isPinned;
        await repo.save();
      }
    }

    if (!repo) {
      return res.status(404).json({ message: 'Repository not found' });
    }

    res.status(200).json({
      success: true,
      repository: repo
    });
  } catch (error) {
    res.status(500).json({ message: `Pin Error: ${error.message}` });
  }
});

// @desc    Toggle star status for a repository
// @route   POST /api/profile/repos/star
// @access  Private
router.post('/repos/star', protect, async (req, res) => {
  try {
    const { repoId } = req.body;
    let repo = null;

    if (!isDbConnected()) {
      repo = mockRepositories.find(r => r.repoId === repoId);
      if (repo) {
        repo.stars += 1;
        mockActivities.push({
          uid: mockUsers[0].uid,
          activityType: 'starred',
          repository: repo.repoName,
          details: `Starred the repository: ${repo.repoName}.`,
          createdAt: new Date().toISOString()
        });
      }
    } else {
      repo = await Repository.findOne({ repoId });
      if (repo) {
        const user = await User.findById(req.user.id);
        repo.stars += 1;
        await repo.save();
        await Activity.create({
          uid: user.uid,
          activityType: 'starred',
          repository: repo.repoName,
          details: `Starred the repository: ${repo.repoName}.`
        });
      }
    }

    if (!repo) {
      return res.status(404).json({ message: 'Repository not found' });
    }

    res.status(200).json({
      success: true,
      repository: repo
    });
  } catch (error) {
    res.status(500).json({ message: `Star Error: ${error.message}` });
  }
});

export default router;
