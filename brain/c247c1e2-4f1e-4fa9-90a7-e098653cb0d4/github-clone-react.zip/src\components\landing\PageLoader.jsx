import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Github } from 'lucide-react';

export default function PageLoader() {
  const [progress, setProgress] = useState(0);
  const [show, setShow] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => setShow(false), 300);
          return 100;
        }
        return prev + Math.floor(Math.random() * 12) + 6;
      });
    }, 80);

    return () => clearInterval(interval);
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          exit={{ opacity: 0 }}
          transition={{ duration: 0.45, ease: 'easeInOut' }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#0D1117] select-none"
        >
          <div className="space-y-6 text-center max-w-xs w-full px-6">
            <Github className="w-14 h-14 text-white mx-auto animate-pulse" />
            <div className="space-y-2">
              <div className="h-1 w-full bg-neutral-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-github-light-success dark:bg-github-dark-success transition-all duration-150"
                  style={{ width: `${Math.min(progress, 100)}%` }}
                />
              </div>
              <p className="text-[9px] uppercase font-black tracking-widest text-github-light-textMuted dark:text-github-dark-textMuted">
                Initializing... {Math.min(progress, 100)}%
              </p>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
export { PageLoader };
