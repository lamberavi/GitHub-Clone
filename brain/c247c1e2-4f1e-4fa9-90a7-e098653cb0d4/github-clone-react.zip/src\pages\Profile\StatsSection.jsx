import React from 'react';
import { BookOpen, Star, GitCommit, Code } from 'lucide-react';

export default function StatsSection({ repositories = [], contributions = [], user }) {
  const totalStars = repositories.reduce((acc, curr) => acc + (curr.stars || 0), 0);
  const totalCommits = contributions.reduce((acc, curr) => acc + (curr.commitCount || 0), 0);
  
  const languages = repositories.map(r => r.language).filter(Boolean);
  const uniqueLangs = [...new Set(languages)].length;

  const statCards = [
    { label: 'Repositories', value: repositories.length, icon: BookOpen, color: 'text-blue-400' },
    { label: 'Total Stars', value: totalStars, icon: Star, color: 'text-amber-400' },
    { label: 'Total Commits', value: totalCommits, icon: GitCommit, color: 'text-emerald-400' },
    { label: 'Languages Used', value: uniqueLangs, icon: Code, color: 'text-purple-400' }
  ];

  return (
    <div className="space-y-6 select-none">
      <h3 className="text-xs font-black uppercase tracking-wider text-[#8b949e]">Developer Overview & Metrics</h3>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {statCards.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <div key={idx} className="glass-panel p-4 rounded-xl border border-[#30363d]/60 hover:border-[#58a6ff]/40 transition-all space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-2xs font-black text-[#8b949e] uppercase tracking-wide">{stat.label}</span>
                <Icon size={16} className={stat.color} />
              </div>
              <p className="text-2xl font-black text-white">{stat.value}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
