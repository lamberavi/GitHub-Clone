import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AuthLayout from '../auth/AuthLayout';
import MainLayout from '../layouts/MainLayout';
import ProtectedRoute from './ProtectedRoute';

// Public Pages
import Landing from '../pages/Landing';
import Login from '../auth/Login';
import Signup from '../auth/Signup';
import ForgotPassword from '../auth/ForgotPassword';
import ResetPassword from '../pages/ResetPassword';
import VerifyEmail from '../pages/VerifyEmail';
import NotFound from '../pages/NotFound';

// Protected Core Pages
import Dashboard from '../pages/Dashboard';
import Profile from '../pages/Profile/Profile';
import Repositories from '../pages/Repositories';
import RepoDetails from '../pages/RepoDetails';
import Search from '../pages/Search';
import Notifications from '../pages/Notifications';
import Settings from '../pages/Settings';
import AdminDashboard from '../pages/AdminDashboard';

// Profile Dropdown Pages
import Stars from '../pages/Stars';
import Gists from '../pages/Gists';
import Organizations from '../pages/Organizations';
import Enterprises from '../pages/Enterprises';
import Sponsors from '../pages/Sponsors';
import Copilot from '../pages/Copilot';
import FeaturePreview from '../pages/FeaturePreview';
import Appearance from '../pages/Appearance';
import Accessibility from '../pages/Accessibility';
import Enterprise from '../pages/Enterprise';
import Status from '../pages/Status';

// Sidebar Navigation Pages
import Issues from '../pages/Issues';
import PullRequests from '../pages/PullRequests';
import Projects from '../pages/Projects';
import Discussions from '../pages/Discussions';
import Codespaces from '../pages/Codespaces';
import Explore from '../pages/Explore';
import Marketplace from '../pages/Marketplace';
import MCPRegistry from '../pages/MCPRegistry';

export default function AppRoutes() {
  return (
    <Routes>
      {/* Landing Page */}
      <Route path="/" element={<Landing />} />

      {/* Authentication Router */}
      <Route element={<AuthLayout />}>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Signup />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/verify-email" element={<VerifyEmail />} />
      </Route>

      {/* Protected App Layout */}
      <Route element={<ProtectedRoute />}>
        <Route element={<MainLayout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/repositories" element={<Repositories />} />
          <Route path="/repo/:repoId" element={<RepoDetails />} />
          <Route path="/search" element={<Search />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/admin" element={<AdminDashboard />} />

          {/* Profile Dropdown Navigation Routes */}
          <Route path="/stars" element={<Stars />} />
          <Route path="/gists" element={<Gists />} />
          <Route path="/organizations" element={<Organizations />} />
          <Route path="/enterprises" element={<Enterprises />} />
          <Route path="/sponsors" element={<Sponsors />} />
          <Route path="/copilot" element={<Copilot />} />
          <Route path="/feature-preview" element={<FeaturePreview />} />
          <Route path="/appearance" element={<Appearance />} />
          <Route path="/accessibility" element={<Accessibility />} />
          <Route path="/enterprise" element={<Enterprise />} />
          <Route path="/status" element={<Status />} />

          {/* Sidebar Navigation Routes */}
          <Route path="/issues" element={<Issues />} />
          <Route path="/pull-requests" element={<PullRequests />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/discussions" element={<Discussions />} />
          <Route path="/codespaces" element={<Codespaces />} />
          <Route path="/explore" element={<Explore />} />
          <Route path="/marketplace" element={<Marketplace />} />
          <Route path="/mcp-registry" element={<MCPRegistry />} />
        </Route>
      </Route>

      {/* 404 Fallback */}
      <Route path="/404" element={<NotFound />} />
      <Route path="*" element={<Navigate to="/404" replace />} />
    </Routes>
  );
}
