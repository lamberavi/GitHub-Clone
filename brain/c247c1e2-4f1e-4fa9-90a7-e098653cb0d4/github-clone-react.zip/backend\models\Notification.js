import mongoose from 'mongoose';

const notificationSchema = new mongoose.Schema(
  {
    uid: {
      type: String,
      required: true,
      index: true
    },
    title: {
      type: String,
      required: true
    },
    message: {
      type: String,
      default: ''
    },
    type: {
      type: String, // 'repo', 'issue', 'pr', 'system', 'star'
      default: 'system'
    },
    isRead: {
      type: Boolean,
      default: false
    }
  },
  {
    timestamps: true
  }
);

export const Notification = mongoose.model('Notification', notificationSchema);
export default Notification;
