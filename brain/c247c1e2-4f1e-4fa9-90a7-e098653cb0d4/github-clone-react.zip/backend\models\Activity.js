import mongoose from 'mongoose';

const activitySchema = new mongoose.Schema(
  {
    uid: {
      type: String,
      required: true,
      index: true
    },
    activityType: {
      type: String, // 'commit', 'repo_created', 'starred', 'profile_update', 'pull_request', 'issue'
      required: true
    },
    repository: {
      type: String,
      default: ''
    },
    details: {
      type: String,
      default: ''
    }
  },
  {
    timestamps: true
  }
);

export const Activity = mongoose.model('Activity', activitySchema);
export default Activity;
