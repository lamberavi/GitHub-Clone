import React, { useState, useEffect } from 'react';
import { Outlet, Link, useNavigate, useLocation, Navigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Menu, X, Bell, Search, Moon, Sun, Monitor, 
  ChevronDown, LayoutDashboard, Folder, CircleDot, 
  GitPullRequest, BarChart3, Settings, LogOut, Github, User
} from 'lucide-react';
import { setTheme, initializeTheme } from '../redux/slices/themeSlice';
import { setSearch } from '../redux/slices/repoSlice';
import useAuth from '../hooks/useAuth';
import Sidebar from '../components/Sidebar/Sidebar';
import ProfileDropdown from '../components/navigation/ProfileDropdown';

export default function MainLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();
  const { logout } = useAuth();
  
  const { user, isAuthenticated } = useSelector((state) => state.auth);
  const { theme } = useSelector((state) => state.theme);
  const unreadCount = useSelector((state) => state.notifications.unreadCount) || 0;
  
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [isThemeDropdownOpen, setIsThemeDropdownOpen] = useState(false);
  const [localSearch, setLocalSearch] = useState('');

  // Initial theme loader
  useEffect(() => {
    dispatch(initializeTheme());
  }, [dispatch]);

  // Handle redirect if not authenticated
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Repositories', path: '/repositories', icon: Folder },
    { name: 'Profile', path: '/profile', icon: User },
    { name: 'Notifications', path: '/notifications', icon: Bell, badge: unreadCount },
    { name: 'Settings', path: '/settings', icon: Settings },
    { name: 'Admin Panel', path: '/admin', icon: BarChart3 }
  ];

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (localSearch.trim()) {
      dispatch(setSearch({ query: localSearch, filter: 'all' }));
      navigate('/search');
    }
  };

  const handleThemeChange = (newTheme) => {
    dispatch(setTheme(newTheme));
    setIsThemeDropdownOpen(false);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const photo = user?.photo || user?.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80';

  return (
    <div className="min-h-screen flex flex-col bg-[#0d1117] text-[#c9d1d9] select-none">
      
      {/* Top Navbar */}
      <header className="sticky top-0 z-40 w-full border-b border-[#30363d] bg-[#161b22]/90 backdrop-blur-md">
        <div className="px-4 h-16 flex items-center justify-between gap-4">
          
          {/* Logo & Hamburger */}
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
              className="lg:hidden p-2 hover:bg-[#21262d] rounded-lg text-[#8b949e]"
            >
              <Menu size={20} />
            </button>
            
            <button 
              onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)} 
              className="hidden lg:flex p-2 hover:bg-[#21262d] rounded-lg text-[#8b949e]"
            >
              <Menu size={20} />
            </button>
            
            <Link to="/dashboard" className="flex items-center gap-2 font-bold text-lg tracking-tight text-white">
              <Github className="w-7 h-7 text-white" />
              <span className="hidden sm:inline">GitHub</span>
              <span className="text-[#58a6ff] text-xs font-semibold border border-[#58a6ff]/30 px-1.5 py-0.5 rounded-md">IDE</span>
            </Link>
          </div>

          {/* Search bar */}
          <form onSubmit={handleSearchSubmit} className="flex-1 max-w-md hidden md:block">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8b949e]" />
              <input
                type="text"
                placeholder="Search or type '/' to launch query..."
                value={localSearch}
                onChange={(e) => setLocalSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-1.5 text-xs bg-[#0d1117] border border-[#30363d] rounded-lg outline-none focus:border-[#58a6ff] text-white"
              />
            </div>
          </form>

          {/* Right Header Navigation Items */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Notification Bell */}
            <Link 
              to="/notifications" 
              className="relative p-2 text-[#8b949e] hover:text-white hover:bg-[#21262d] rounded-lg transition-colors"
              title="Notifications"
            >
              <Bell size={18} />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-blue-500 rounded-full animate-ping" />
              )}
            </Link>

            {/* Profile Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
                className="flex items-center gap-2 p-1 rounded-full hover:bg-[#21262d] transition-colors cursor-pointer"
              >
                <img
                  src={photo}
                  alt={user?.firstName || 'User'}
                  className="w-8 h-8 rounded-full border border-[#30363d] object-cover"
                />
                <ChevronDown size={14} className="text-[#8b949e]" />
              </button>

              <AnimatePresence>
                {isProfileDropdownOpen && (
                  <ProfileDropdown
                    user={user}
                    onClose={() => setIsProfileDropdownOpen(false)}
                    onLogout={handleLogout}
                  />
                )}
              </AnimatePresence>
            </div>

          </div>
        </div>
      </header>

      {/* Main Body with Collapsible Sidebar */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Modular GitHub Home Sidebar */}
        <Sidebar 
          isOpen={isMobileMenuOpen} 
          onClose={() => setIsMobileMenuOpen(false)} 
        />

        {/* Dynamic Route Content Outlet */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#0d1117]">
          <Outlet />
        </main>
      </div>

    </div>
  );
}
