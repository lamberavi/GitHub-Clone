import mongoose from 'mongoose';

const contributionSchema = new mongoose.Schema(
  {
    uid: {
      type: String,
      required: true,
      index: true
    },
    date: {
      type: String, // YYYY-MM-DD format
      required: true
    },
    commitCount: {
      type: Number,
      default: 1
    }
  },
  {
    timestamps: true
  }
);

contributionSchema.index({ uid: 1, date: 1 }, { unique: true });

export const Contribution = mongoose.model('Contribution', contributionSchema);
export default Contribution;
