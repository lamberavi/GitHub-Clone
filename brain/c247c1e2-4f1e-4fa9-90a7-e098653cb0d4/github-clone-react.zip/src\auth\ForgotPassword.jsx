import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Github, ArrowLeft } from 'lucide-react';
import Input from '../components/common/Input';
import Button from '../components/common/Button';
import useAuth from '../hooks/useAuth';
import { forgotPasswordSchema } from '../utils/validators';

export default function ForgotPassword() {
  const { forgotPassword } = useAuth();
  const [isSent, setIsSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [submittedEmail, setSubmittedEmail] = useState('');

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm({
    resolver: zodResolver(forgotPasswordSchema)
  });

  const onSubmit = async (data) => {
    setIsLoading(true);
    try {
      await forgotPassword(data.email);
      setSubmittedEmail(data.email);
      setIsSent(true);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Info */}
      <div className="text-center space-y-2">
        <Link to="/" className="inline-flex justify-center mb-2">
          <Github className="w-10 h-10 text-github-light-text dark:text-github-dark-text animate-pulse-slow" />
        </Link>
        <h2 className="text-2xl font-bold tracking-tight">Reset your password</h2>
        <p className="text-sm text-github-light-textMuted dark:text-github-dark-textMuted">
          We will send you an email containing instructions to securely reset your credentials.
        </p>
      </div>

      {!isSent ? (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <Input
            label="Email address"
            type="email"
            placeholder="e.g. ravil@antigravity.io"
            {...register('email')}
            error={errors.email?.message}
            disabled={isLoading}
          />

          <Button 
            type="submit" 
            className="w-full py-2.5 mt-2" 
            isLoading={isLoading}
          >
            Send recovery link
          </Button>

          <Link to="/login" className="flex items-center justify-center gap-2 text-xs font-semibold text-github-light-textMuted dark:text-github-dark-textMuted hover:text-github-light-text dark:hover:text-github-dark-text transition-colors">
            <ArrowLeft size={12} /> Back to Sign In
          </Link>
        </form>
      ) : (
        <div className="text-center space-y-4 py-4">
          <div className="w-12 h-12 bg-github-light-success/15 dark:bg-github-dark-success/15 rounded-full flex items-center justify-center text-github-light-success dark:text-github-dark-success mx-auto text-xl animate-bounce">
            ✓
          </div>
          <h3 className="font-semibold text-lg">Check your inbox</h3>
          <p className="text-sm text-github-light-textMuted dark:text-github-dark-textMuted">
            An email containing recovery steps has been dispatched to <span className="font-bold text-github-light-text dark:text-github-dark-text">{submittedEmail}</span>. Please verify your folder logs.
          </p>
          <Link to="/login">
            <Button className="w-full py-2.5 mt-4">Proceed to Sign In</Button>
          </Link>
        </div>
      )}

    </div>
  );
}
export { ForgotPassword };
