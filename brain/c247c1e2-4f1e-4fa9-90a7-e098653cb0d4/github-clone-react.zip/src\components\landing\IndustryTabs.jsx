import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Building, Compass, Users2 } from 'lucide-react';
import Badge from '../common/Badge';

export default function IndustryTabs() {
  const [activeSegment, setActiveSegment] = useState('industry'); // industry, size, usecase

  const segments = [
    { id: 'industry', label: 'By Industry', icon: Building },
    { id: 'size', label: 'By Business Size', icon: Users2 },
    { id: 'usecase', label: 'By Use Case', icon: Compass }
  ];

  const dataMap = {
    industry: [
      { tag: 'Finance', title: 'High-security banking infrastructure', desc: 'LDAP access overrides and telemetry logs complying with strict financial guidelines.', metric: 'SOC 2 / ISO' },
      { tag: 'Healthcare', title: 'HIPAA-compliant workspace pipelines', desc: 'Secure repository encryptions safeguarding user data and logs.', metric: 'HIPAA Ready' },
      { tag: 'Automotive', title: 'Embedded firmware delivery boards', desc: 'Continuous integration compile tools accelerating vehicle telemetry updates.', metric: 'Automated CI' }
    ],
    size: [
      { tag: 'Startups', title: 'Spin up workspaces for free', desc: 'Access in-memory databases, file explorers, and code edits immediately.', metric: 'Free Tier' },
      { tag: 'Teams', title: 'Collaborate with custom seats', desc: 'Sync branch targets, open pull requests, and review commits collectively.', metric: 'Seat Config' },
      { tag: 'Enterprise', title: 'Advanced governance structures', desc: 'Federated single sign-on logs and central admin analytics monitors.', metric: 'SSO & Audits' }
    ],
    usecase: [
      { tag: 'Security', title: 'Telemetry vulnerability checkers', desc: 'Audit system actions and track directory modifications from security panels.', metric: 'Access Audit' },
      { tag: 'Automation', title: 'Trigger actions on repository push', desc: 'Automate build compiles and chart contributor velocities on graphs.', metric: 'Auto Hooks' },
      { tag: 'Code Review', title: 'High-fidelity diff reviews', desc: 'Analyze side-by-side split diff lines and write comment threads.', metric: 'Diff Engine' }
    ]
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-12 space-y-8">
      
      {/* Segment Selector Tabs */}
      <div className="flex justify-center border-b border-github-light-border/40 dark:border-github-dark-border/40 pb-4 flex-wrap gap-1">
        {segments.map((seg) => {
          const Icon = seg.icon;
          const isActive = activeSegment === seg.id;

          return (
            <button
              key={seg.id}
              onClick={() => setActiveSegment(seg.id)}
              className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-lg transition-colors cursor-pointer select-none whitespace-nowrap ${
                isActive 
                  ? 'bg-github-light-accent/10 dark:bg-github-dark-accent/15 text-github-light-accent dark:text-github-dark-accent' 
                  : 'text-github-light-textMuted dark:text-github-dark-textMuted hover:text-github-light-text hover:bg-neutral-100 dark:hover:bg-neutral-850/40'
              }`}
            >
              <Icon size={15} />
              <span>{seg.label}</span>
            </button>
          );
        })}
      </div>

      {/* Cards list grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <AnimatePresence mode="wait">
          {dataMap[activeSegment].map((item, idx) => (
            <motion.div
              key={item.tag}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3, delay: idx * 0.05 }}
              className="glass-panel p-5 rounded-2xl border border-github-light-border/60 dark:border-github-dark-border/60 hover:border-github-light-accent/40 dark:hover:border-github-dark-accent/40 hover:shadow-glow transition-all duration-300 flex flex-col justify-between min-h-[220px] custom-shadow group"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-center gap-2">
                  <span className="text-[10px] text-github-light-textMuted dark:text-github-dark-textMuted uppercase font-extrabold tracking-wider">
                    {item.tag}
                  </span>
                  <Badge variant="neutral" size="sm">
                    {item.metric}
                  </Badge>
                </div>
                
                <h4 className="text-sm sm:text-base font-bold text-github-light-text dark:text-github-dark-text leading-snug group-hover:text-github-light-accent dark:group-hover:text-github-dark-accent transition-colors">
                  {item.title}
                </h4>
              </div>

              <p className="text-xs text-github-light-textMuted dark:text-github-dark-textMuted leading-relaxed pt-2">
                {item.desc}
              </p>

            </motion.div>
          ))}
        </AnimatePresence>
      </div>

    </div>
  );
}
