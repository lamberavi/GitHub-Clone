import React from 'react';

export default function CardBorder({ children, isActive = false }) {
  return (
    <div className={`w-full h-full rounded-2xl border transition-all duration-300 ${
      isActive 
        ? 'border-[#bc8cff]/55 shadow-[0_0_20px_1px_rgba(188,140,255,0.18)]' 
        : 'border-[#30363D]/75 group-hover:border-[#58a6ff]/45'
    }`}>
      {children}
    </div>
  );
}
export { CardBorder };
