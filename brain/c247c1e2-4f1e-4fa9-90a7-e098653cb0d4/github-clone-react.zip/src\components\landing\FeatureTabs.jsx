import React from 'react';
import { motion } from 'framer-motion';
import { Code, Calendar, Users, Cpu, Shield } from 'lucide-react';

export default function FeatureTabs({ activeTab, onTabChange }) {
  const tabs = [
    { id: 'code', label: 'Code', icon: Code },
    { id: 'plan', label: 'Plan', icon: Calendar },
    { id: 'collaborate', label: 'Collaborate', icon: Users },
    { id: 'automate', label: 'Automate', icon: Cpu },
    { id: 'secure', label: 'Secure', icon: Shield }
  ];

  return (
    <div className="w-full flex justify-center border-b border-github-light-border/40 dark:border-github-dark-border/40 mb-12 overflow-x-auto scrollbar-none">
      <div className="flex gap-2 p-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`relative flex items-center gap-2 px-5 py-3 text-sm font-semibold rounded-lg transition-colors cursor-pointer select-none whitespace-nowrap ${
                isActive 
                  ? 'text-github-light-accent dark:text-github-dark-accent' 
                  : 'text-github-light-textMuted dark:text-github-dark-textMuted hover:text-github-light-text dark:hover:text-github-dark-text'
              }`}
            >
              <Icon size={16} />
              <span>{tab.label}</span>
              
              {/* Animated underline highlighter */}
              {isActive && (
                <motion.div
                  layoutId="activeUnderline"
                  className="absolute bottom-[-5px] left-0 right-0 h-[2.5px] bg-github-light-accent dark:bg-github-dark-accent rounded-full"
                  transition={{ type: 'spring', damping: 20, stiffness: 220 }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
