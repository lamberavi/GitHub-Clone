import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Github, LogIn, Eye, EyeOff } from 'lucide-react';
import Input from '../components/common/Input';
import Button from '../components/common/Button';
import useAuth from '../hooks/useAuth';
import { loginSchema } from '../utils/validators';
import GoogleLogin from './GoogleLogin';

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm({
    resolver: zodResolver(loginSchema)
  });

  const onSubmit = async (data) => {
    setIsLoading(true);
    try {
      await login(data.email, data.password);
      navigate('/dashboard');
    } catch (err) {
      if (err.message === 'UNVERIFIED_EMAIL') {
        navigate('/verify-email');
      } else {
        console.error(err);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Info */}
      <div className="text-center space-y-2">
        <Link to="/" className="inline-flex justify-center mb-2">
          <Github className="w-10 h-10 text-github-light-text dark:text-github-dark-text animate-pulse-slow" />
        </Link>
        <h2 className="text-2xl font-bold tracking-tight">Sign in to your account</h2>
        <p className="text-sm text-github-light-textMuted dark:text-github-dark-textMuted">
          Or{' '}
          <Link to="/register" className="font-semibold text-github-light-accent dark:text-github-dark-accent hover:underline">
            create a free workspace
          </Link>
        </p>
      </div>

      {/* Main Form */}
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <Input
            label="Email address"
            type="email"
            placeholder="e.g. ravil@antigravity.io"
            {...register('email')}
            error={errors.email?.message}
            disabled={isLoading}
          />
        </div>

        <div className="space-y-1">
          <div className="flex justify-between items-center">
            <label className="text-xs font-semibold text-github-light-textMuted dark:text-github-dark-textMuted">
              Password <span className="text-github-light-danger dark:text-github-dark-danger">*</span>
            </label>
            <Link to="/forgot-password" className="text-xs font-semibold text-github-light-accent dark:text-github-dark-accent hover:underline">
              Forgot password?
            </Link>
          </div>
          
          <div className="relative">
            <Input
              type={showPassword ? 'text' : 'password'}
              placeholder="••••••••"
              {...register('password')}
              error={errors.password?.message}
              disabled={isLoading}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-github-light-textMuted dark:text-github-dark-textMuted hover:text-github-light-text dark:hover:text-github-dark-text transition-colors p-1 cursor-pointer select-none"
            >
              {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <input
              id="remember-me"
              name="remember-me"
              type="checkbox"
              className="h-4 w-4 rounded border-github-light-border dark:border-github-dark-border bg-github-light-bg dark:bg-github-dark-bg text-github-light-accent dark:text-github-dark-accent focus:ring-github-light-accent/30 dark:focus:ring-github-dark-accent/30 outline-none cursor-pointer"
            />
            <label htmlFor="remember-me" className="ml-2 block text-sm select-none cursor-pointer text-github-light-textMuted dark:text-github-dark-textMuted">
              Keep me signed in
            </label>
          </div>
        </div>

        <Button 
          type="submit" 
          className="w-full py-2.5 mt-2" 
          isLoading={isLoading}
          icon={LogIn}
        >
          Sign In
        </Button>
      </form>

      {/* Social login line divider */}
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-github-light-border/60 dark:border-github-dark-border/60" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-github-light-card dark:bg-github-dark-card px-2 text-github-light-textMuted dark:text-github-dark-textMuted">
            Or continue with
          </span>
        </div>
      </div>

      {/* Google Sign In Component */}
      <GoogleLogin disabled={isLoading} onLoadChange={setIsLoading} />

    </div>
  );
}
export { Login };
