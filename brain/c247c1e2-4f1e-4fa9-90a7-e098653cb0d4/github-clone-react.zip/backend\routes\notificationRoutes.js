import express from 'express';
import mongoose from 'mongoose';
import Notification from '../models/Notification.js';
import protect from '../middleware/authMiddleware.js';

const router = express.Router();

// Helper: Check connection state
const isDbConnected = () => mongoose.connection.readyState === 1;

let mockNotifications = [
  {
    _id: 'notif_1',
    uid: 'mock_uid_dev',
    title: 'Welcome to Antigravity GitHub Clone!',
    message: 'Your developer workspace has been configured successfully.',
    type: 'system',
    isRead: false,
    createdAt: new Date().toISOString()
  },
  {
    _id: 'notif_2',
    uid: 'mock_uid_dev',
    title: 'Repository Pinned',
    message: 'github-clone-react was pinned to your overview page.',
    type: 'repo',
    isRead: false,
    createdAt: new Date().toISOString()
  }
];

// @desc    Get user notifications
// @route   GET /api/notifications
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    let notifications = [];
    if (!isDbConnected()) {
      notifications = mockNotifications;
    } else {
      notifications = await Notification.find({ uid: req.user.uid }).sort({ createdAt: -1 });
    }

    res.status(200).json({
      success: true,
      notifications,
      unreadCount: notifications.filter(n => !n.isRead).length
    });
  } catch (error) {
    res.status(500).json({ message: `Notifications Fetch Error: ${error.message}` });
  }
});

// @desc    Mark notification as read
// @route   PUT /api/notifications/:id/read
// @access  Private
router.put('/:id/read', protect, async (req, res) => {
  try {
    const { id } = req.params;
    if (!isDbConnected()) {
      const target = mockNotifications.find(n => n._id === id);
      if (target) target.isRead = true;
    } else {
      await Notification.findByIdAndUpdate(id, { isRead: true });
    }

    res.status(200).json({ success: true, message: 'Notification marked as read.' });
  } catch (error) {
    res.status(500).json({ message: `Notification Read Error: ${error.message}` });
  }
});

export default router;
