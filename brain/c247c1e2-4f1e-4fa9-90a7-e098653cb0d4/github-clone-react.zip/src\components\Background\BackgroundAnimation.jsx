import React from 'react';
import GlobalGradient from './GlobalGradient';
import GlowLayer from './GlowLayer';
import ParticleLayer from './ParticleLayer';
import NoiseLayer from './NoiseLayer';
import StarsLayer from './StarsLayer';

export default function BackgroundAnimation() {
  return (
    <div className="absolute inset-0 z-0 w-full h-full">
      <GlobalGradient />
      <GlowLayer />
      <StarsLayer />
      <ParticleLayer />
      <NoiseLayer />
    </div>
  );
}
export { BackgroundAnimation };
