import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { 
  Star, GitFork, Eye, Play, Plus, BookOpen, 
  Terminal, CircleDot, GitPullRequest, Code, Settings, History, GitBranch
} from 'lucide-react';
import Button from '../components/common/Button';
import Badge from '../components/common/Badge';
import Modal from '../components/common/Modal';
import Input from '../components/common/Input';

// Custom subcomponents
import FileExplorer from '../components/repository/FileExplorer';
import MonacoEditor from '../components/editor/MonacoEditor';
import IssueList from '../components/issue/IssueList';
import PRList from '../components/pullrequest/PRList';

// Redux Actions
import { 
  setActiveRepo, setActiveBranch, addBranch, setSelectedFile 
} from '../redux/slices/repoSlice';

export default function RepoDetails() {
  const { repoId } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { repositories, activeBranch, selectedFile } = useSelector((state) => state.repos);
  
  const [activeTab, setActiveTab] = useState('code'); // code, issues, pulls, commits, branches, settings
  const [isBranchModalOpen, setIsBranchModalOpen] = useState(false);
  const [newBranchName, setNewBranchName] = useState('');
  
  const [isStarred, setIsStarred] = useState(false);
  const [starCount, setStarCount] = useState(0);

  // Find active repo
  const repo = repositories.find((r) => r.id === repoId);

  useEffect(() => {
    if (repoId) {
      dispatch(setActiveRepo(repoId));
    }
  }, [repoId, dispatch]);

  useEffect(() => {
    if (repo) {
      setStarCount(repo.stars);
    }
  }, [repo]);

  if (!repo) {
    return (
      <div className="text-center py-16">
        <p className="text-sm text-github-light-textMuted dark:text-github-dark-textMuted">Repository not found.</p>
        <Button onClick={() => navigate('/dashboard')} className="mt-4">Back to Dashboard</Button>
      </div>
    );
  }

  const handleStarToggle = () => {
    if (isStarred) {
      setStarCount(starCount - 1);
      setIsStarred(false);
    } else {
      setStarCount(starCount + 1);
      setIsStarred(true);
    }
  };

  const handleCreateBranch = (e) => {
    e.preventDefault();
    if (!newBranchName.trim()) return;

    dispatch(addBranch(newBranchName));
    setNewBranchName('');
    setIsBranchModalOpen(false);
  };

  const tabs = [
    { id: 'code', label: 'Code', icon: Code },
    { id: 'issues', label: 'Issues', icon: CircleDot, badge: repo.issues.length },
    { id: 'pulls', label: 'Pull Requests', icon: GitPullRequest, badge: repo.pullRequests.length },
    { id: 'commits', label: 'Commits', icon: History, badge: repo.commits.length },
    { id: 'branches', label: 'Branches', icon: GitBranch, badge: repo.branches.length },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <div className="space-y-6">
      
      {/* 1. Repository Info Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-github-light-border/60 dark:border-github-dark-border/60 pb-5">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <BookOpen className="text-github-light-textMuted dark:text-github-dark-textMuted w-5 h-5 shrink-0" />
            <h1 className="text-xl font-bold flex items-center gap-1.5 truncate">
              <span className="text-github-light-accent dark:text-github-dark-accent hover:underline cursor-pointer">{repo.owner}</span>
              <span className="text-github-light-textMuted dark:text-github-dark-textMuted">/</span>
              <span className="truncate">{repo.name}</span>
            </h1>
            <Badge variant={repo.isPrivate ? 'neutral' : 'info'} size="sm">
              {repo.isPrivate ? 'Private' : 'Public'}
            </Badge>
          </div>
          <p className="text-xs text-github-light-textMuted dark:text-github-dark-textMuted mt-1.5 leading-relaxed max-w-2xl">
            {repo.description}
          </p>
        </div>

        {/* Action Widgets */}
        <div className="flex flex-wrap gap-2 shrink-0">
          <Button 
            size="sm" 
            variant={isStarred ? 'primary' : 'outline'} 
            icon={Star}
            onClick={handleStarToggle}
            className="h-8"
          >
            {isStarred ? 'Starred' : 'Star'} <span className="ml-1 px-1 py-0.2 bg-black/10 dark:bg-white/10 rounded-full text-3xs font-semibold">{starCount}</span>
          </Button>
          <Button size="sm" variant="outline" icon={GitFork} className="h-8">
            Fork <span className="ml-1 px-1 py-0.2 bg-black/10 dark:bg-white/10 rounded-full text-3xs font-semibold">{repo.forks}</span>
          </Button>
          <Button size="sm" variant="outline" icon={Eye} className="h-8">
            Watch
          </Button>
        </div>
      </div>

      {/* 2. Top-level Navigation Tabs */}
      <div className="flex border-b border-github-light-border/60 dark:border-github-dark-border/60 overflow-x-auto scrollbar-none gap-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id); dispatch(setSelectedFile(null)); }}
              className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 -mb-[2px] whitespace-nowrap transition-colors ${
                isActive
                  ? 'border-github-light-accent dark:border-github-dark-accent text-github-light-text dark:text-github-dark-text'
                  : 'border-transparent text-github-light-textMuted dark:text-github-dark-textMuted hover:text-github-light-text'
              }`}
            >
              <Icon size={14} />
              <span>{tab.label}</span>
              {tab.badge !== undefined && tab.badge > 0 && (
                <span className="px-1.5 py-0.1 bg-neutral-100 dark:bg-github-dark-border text-github-light-textMuted dark:text-github-dark-textMuted rounded-full text-3xs font-bold">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* 3. Tab contents router */}
      <div className="pt-2">
        
        {/* CODE TAB */}
        {activeTab === 'code' && (
          <div className="space-y-4">
            {!selectedFile ? (
              <div className="space-y-4">
                {/* Branch controls select bar */}
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2">
                    <select
                      value={activeBranch}
                      onChange={(e) => dispatch(setActiveBranch(e.target.value))}
                      className="px-3 py-1.5 text-xs font-semibold bg-github-light-bg dark:bg-github-dark-bg border border-github-light-border dark:border-github-dark-border rounded-lg cursor-pointer outline-none focus:ring-1 focus:ring-github-light-accent/30 dark:focus:ring-github-dark-accent/30"
                    >
                      {repo.branches.map((b) => (
                        <option key={b} value={b}>{b}</option>
                      ))}
                    </select>
                    
                    <Button 
                      size="sm" 
                      variant="outline" 
                      icon={Plus} 
                      onClick={() => setIsBranchModalOpen(true)}
                      className="h-8 px-2"
                    >
                      New Branch
                    </Button>
                  </div>

                  <div className="text-2xs font-semibold text-github-light-textMuted dark:text-github-dark-textMuted flex gap-3">
                    <span><span className="text-github-light-text dark:text-github-dark-text">{repo.branches.length}</span> branches</span>
                    <span><span className="text-github-light-text dark:text-github-dark-text">{repo.commits.length}</span> commits</span>
                  </div>
                </div>

                {/* File Explorer listing */}
                <FileExplorer filesNode={repo.files} commits={repo.commits} />
              </div>
            ) : (
              /* Monaco Code view */
              <MonacoEditor file={selectedFile} repoId={repo.id} />
            )}
          </div>
        )}

        {/* ISSUES TAB */}
        {activeTab === 'issues' && (
          <IssueList issues={repo.issues} repoId={repo.id} />
        )}

        {/* PULL REQUESTS TAB */}
        {activeTab === 'pulls' && (
          <PRList prs={repo.pullRequests} branches={repo.branches} repoId={repo.id} />
        )}

        {/* COMMITS HISTORY TAB */}
        {activeTab === 'commits' && (
          <div className="space-y-4">
            <h3 className="font-bold text-sm text-github-light-textMuted dark:text-github-dark-textMuted">Commits on {activeBranch}</h3>
            
            <div className="relative border-l border-github-light-border dark:border-github-dark-border pl-6 ml-3 space-y-6">
              {repo.commits.length > 0 ? (
                repo.commits.map((commit, cIdx) => (
                  <div key={commit.id} className="relative group">
                    {/* Circle Node Icon */}
                    <div className="absolute -left-[31px] top-1 w-3.5 h-3.5 rounded-full border-2 border-github-light-border dark:border-github-dark-border bg-github-light-canvas dark:bg-github-dark-canvas group-hover:border-github-light-accent dark:group-hover:border-github-dark-accent transition-colors" />
                    
                    <div className="glass-panel p-4 rounded-xl border border-github-light-border/60 dark:border-github-dark-border/60 hover:border-github-light-accent/30 dark:hover:border-github-dark-accent/30 transition-all flex justify-between gap-4 items-center">
                      <div className="min-w-0 flex-1 space-y-1">
                        <p className="text-sm font-semibold truncate hover:text-github-light-accent dark:hover:text-github-dark-accent cursor-pointer">
                          {commit.message}
                        </p>
                        <p className="text-[10px] text-github-light-textMuted dark:text-github-dark-textMuted">
                          by @{commit.author} committed {new Date(commit.date).toLocaleDateString()}
                        </p>
                      </div>
                      
                      <div className="flex items-center gap-3 font-mono shrink-0">
                        <span className="text-[10px] text-github-light-success dark:text-github-dark-success">
                          {commit.changes}
                        </span>
                        <Badge variant="neutral" size="sm">
                          {commit.id}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-github-light-textMuted dark:text-github-dark-textMuted py-4">No commits recorded on this branch.</p>
              )}
            </div>
          </div>
        )}

        {/* BRANCHES LIST TAB */}
        {activeTab === 'branches' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center flex-wrap gap-2">
              <h3 className="font-bold text-sm text-github-light-textMuted dark:text-github-dark-textMuted">Branch List</h3>
              <Button icon={Plus} size="sm" onClick={() => setIsBranchModalOpen(true)}>
                New Branch
              </Button>
            </div>

            <div className="glass-panel border border-github-light-border/60 dark:border-github-dark-border/60 rounded-xl overflow-hidden divide-y divide-github-light-border/40 dark:divide-github-dark-border/45 custom-shadow">
              {repo.branches.map((br) => (
                <div key={br} className="p-4 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <GitBranch size={16} className="text-github-light-textMuted dark:text-github-dark-textMuted" />
                    <span className="text-sm font-semibold">{br}</span>
                    {br === 'main' && <Badge variant="info" size="sm">Default</Badge>}
                    {br === activeBranch && <Badge variant="success" size="sm">Active</Badge>}
                  </div>
                  
                  {br !== 'main' && (
                    <button 
                      onClick={() => dispatch(setActiveBranch('main'))}
                      className="text-xs text-github-light-accent dark:text-github-dark-accent hover:underline font-semibold"
                    >
                      Reset to Default
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* REPOSITORY SETTINGS TAB */}
        {activeTab === 'settings' && (
          <div className="glass-panel p-6 rounded-xl border border-github-light-border/60 dark:border-github-dark-border/60 custom-shadow space-y-6 max-w-xl">
            <h3 className="font-bold text-base">Repository Settings</h3>
            
            <form onSubmit={(e) => e.preventDefault()} className="space-y-4">
              <Input
                label="Rename Repository"
                name="renameRepo"
                placeholder={repo.name}
                disabled
              />
              <p className="text-2xs text-github-light-textMuted dark:text-github-dark-textMuted">
                Renaming features are locked in demo modes to preserve references.
              </p>
            </form>

            <div className="border-t border-github-light-border/60 dark:border-github-dark-border/60 pt-6 space-y-4">
              <h4 className="text-sm font-bold text-github-light-danger dark:text-github-dark-danger">Danger Zone</h4>
              <div className="p-4 border border-github-light-danger/30 dark:border-github-dark-danger/30 rounded-xl bg-github-light-danger/5 dark:bg-github-dark-danger/5 space-y-3">
                <div className="flex justify-between items-center gap-4">
                  <div>
                    <h5 className="text-xs font-bold">Delete this repository</h5>
                    <p className="text-[10px] text-github-light-textMuted dark:text-github-dark-textMuted mt-0.5">
                      Once deleted, in-memory states will disappear.
                    </p>
                  </div>
                  <Button variant="danger" size="sm" isDisabled>
                    Delete
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* 4. Branch Creator Modal */}
      <Modal
        isOpen={isBranchModalOpen}
        onClose={() => setIsBranchModalOpen(false)}
        title="Create a new branch"
        footer={
          <>
            <Button variant="outline" onClick={() => setIsBranchModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateBranch} isDisabled={!newBranchName.trim()}>
              Create branch
            </Button>
          </>
        }
      >
        <form onSubmit={handleCreateBranch} className="space-y-4">
          <Input
            label="Branch Name"
            name="newBranchName"
            placeholder="e.g. feature/visual-diff"
            value={newBranchName}
            onChange={(e) => setNewBranchName(e.target.value)}
            required
            autoFocus
          />
          <p className="text-2xs text-github-light-textMuted dark:text-github-dark-textMuted leading-normal">
            The branch will spin off from the current head of <code className="px-1.5 py-0.5 rounded bg-neutral-150 dark:bg-github-dark-border">{activeBranch}</code>.
          </p>
        </form>
      </Modal>

    </div>
  );
}
