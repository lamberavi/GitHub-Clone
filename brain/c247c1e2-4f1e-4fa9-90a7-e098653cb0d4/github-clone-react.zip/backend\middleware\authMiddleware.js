import jwt from 'jsonwebtoken';
import mongoose from 'mongoose';
import User from '../models/User.js';

// Check DB Connection State
const isDbConnected = () => mongoose.connection.readyState === 1;

export const protect = async (req, res, next) => {
  let token;

  // 1. Read token from Authorization Header (Bearer token)
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }
  // 2. Read token from Cookies (token or accessToken)
  else if (req.cookies && (req.cookies.token || req.cookies.accessToken)) {
    token = req.cookies.token || req.cookies.accessToken;
  }

  // 3. Fallback for offline / simulated local development mode if no token or disconnected DB
  if (!token) {
    if (!isDbConnected() || process.env.NODE_ENV !== 'production') {
      req.user = {
        id: 'mock_id_dev',
        uid: 'mock_uid_dev',
        username: 'ravil',
        email: 'ravil@antigravity.io'
      };
      return next();
    }
    return res.status(401).json({ message: 'Authentication required. Please sign in to perform this action.' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'antigravity-jwt-secret-key-98124');
    req.user = decoded;
    
    // Attach UID if present
    if (!req.user.uid) {
      req.user.uid = decoded.uid || decoded.id || 'mock_uid_dev';
    }

    next();
  } catch (error) {
    // If token validation fails in offline mode, fall back to default user session
    if (!isDbConnected() || process.env.NODE_ENV !== 'production') {
      req.user = {
        id: 'mock_id_dev',
        uid: 'mock_uid_dev',
        username: 'ravil',
        email: 'ravil@antigravity.io'
      };
      return next();
    }
    res.status(401).json({ message: 'Your session token has expired. Please sign in again.' });
  }
};

export default protect;
