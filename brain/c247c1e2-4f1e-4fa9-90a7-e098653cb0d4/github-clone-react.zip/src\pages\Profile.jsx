import React from 'react';
import { useSelector } from 'react-redux';
import { User, Mail, MapPin, Building, Globe, Calendar, BookOpen, Star, GitFork } from 'lucide-react';
import Badge from '../components/common/Badge';

export default function Profile() {
  const { user } = useSelector((state) => state.auth);
  const repositories = useSelector((state) => state.repos.repositories);

  const currentUser = user || {
    username: 'ravil',
    firstName: 'Ravil',
    lastName: 'L',
    email: 'ravil@example.com',
    bio: 'Full Stack Engineer & Open Source Developer',
    location: 'Bangalore, India',
    company: 'Antigravity IDE',
    website: 'https://github.com',
    createdAt: new Date().toISOString()
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 text-[#c9d1d9] space-y-8 select-none">
      
      {/* Header Banner */}
      <div className="glass-panel p-6 sm:p-8 rounded-2xl border border-[#30363d] flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-2xl font-black text-white shadow-glow">
            {currentUser.firstName ? currentUser.firstName.charAt(0) : 'U'}
          </div>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tight">
              {currentUser.firstName} {currentUser.lastName}
            </h1>
            <p className="text-sm text-[#8b949e] font-semibold">@{currentUser.username}</p>
            <p className="text-xs text-[#8b949e] mt-2 max-w-md line-clamp-2 leading-relaxed">
              {currentUser.bio || 'No bio specified.'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-4 text-xs font-bold text-[#8b949e]">
          {currentUser.location && (
            <span className="flex items-center gap-1.5">
              <MapPin size={14} /> {currentUser.location}
            </span>
          )}
          {currentUser.company && (
            <span className="flex items-center gap-1.5">
              <Building size={14} /> {currentUser.company}
            </span>
          )}
          {currentUser.website && (
            <a href={currentUser.website} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-[#58a6ff] hover:underline">
              <Globe size={14} /> Website
            </a>
          )}
        </div>
      </div>

      {/* Repositories Grid */}
      <div className="space-y-4">
        <h3 className="text-base font-extrabold text-white flex items-center gap-2">
          <BookOpen size={18} className="text-[#8b949e]" />
          <span>Repositories</span>
          <Badge variant="neutral" size="sm" className="bg-[#30363d] text-white">
            {repositories.length}
          </Badge>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {repositories.map((repo) => (
            <div key={repo.id || repo.repoId} className="glass-panel p-4 rounded-xl border border-[#30363d] hover:border-[#58a6ff]/40 transition-all flex flex-col justify-between space-y-3">
              <div>
                <div className="flex justify-between items-start">
                  <h4 className="text-sm font-bold text-[#58a6ff]">{repo.name}</h4>
                  <span className="text-3xs uppercase px-2 py-0.5 rounded border border-[#30363d] text-[#8b949e]">
                    {repo.isPrivate ? 'Private' : 'Public'}
                  </span>
                </div>
                <p className="text-xs text-[#8b949e] mt-1 line-clamp-2">{repo.description || 'No description'}</p>
              </div>

              <div className="flex items-center justify-between text-[10px] text-[#8b949e] font-bold">
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#f1e05a]" />
                  {repo.language || 'JavaScript'}
                </span>
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-0.5"><Star size={11} /> {repo.stars || 0}</span>
                  <span className="flex items-center gap-0.5"><GitFork size={11} /> {repo.forks || 0}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
