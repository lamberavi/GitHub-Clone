import React, { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

export default function Input({
  label,
  name,
  type = 'text',
  placeholder,
  value,
  onChange,
  error,
  required = false,
  className = '',
  ...props
}) {
  const [showPassword, setShowPassword] = useState(false);
  const isPassword = type === 'password';
  const inputType = isPassword ? (showPassword ? 'text' : 'password') : type;

  return (
    <div className={`w-full flex flex-col gap-1.5 ${className}`}>
      {label && (
        <label htmlFor={name} className="text-xs font-semibold text-github-light-textMuted dark:text-github-dark-textMuted">
          {label} {required && <span className="text-github-light-danger dark:text-github-dark-danger">*</span>}
        </label>
      )}
      <div className="relative">
        <input
          id={name}
          name={name}
          type={inputType}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          className={`w-full px-3.5 py-2 text-sm bg-github-light-bg dark:bg-github-dark-bg border rounded-lg outline-none transition-all duration-200 ${
            error
              ? 'border-github-light-danger dark:border-github-dark-danger focus:ring-1 focus:ring-github-light-danger/30 dark:focus:ring-github-dark-danger/30'
              : 'border-github-light-border dark:border-github-dark-border focus:border-github-light-accent dark:focus:border-github-dark-accent focus:ring-1 focus:ring-github-light-accent/30 dark:focus:ring-github-dark-accent/30'
          }`}
          {...props}
        />
        {isPassword && (
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-github-light-textMuted dark:text-github-dark-textMuted hover:text-github-light-text dark:hover:text-github-dark-text"
          >
            {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        )}
      </div>
      {error && (
        <span className="text-xs text-github-light-danger dark:text-github-dark-danger font-medium mt-0.5">
          {error}
        </span>
      )}
    </div>
  );
}
