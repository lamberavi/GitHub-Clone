import React from 'react';
import { Outlet } from 'react-router-dom';
import { motion } from 'framer-motion';

export default function AuthLayout() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-github-light-canvas dark:bg-github-dark-canvas p-4 sm:p-6 transition-colors duration-200 relative overflow-hidden">
      {/* Background gradients for abstract aesthetic */}
      <div className="absolute top-[-20%] left-[-20%] w-[60%] h-[60%] rounded-full bg-github-light-accent/10 dark:bg-github-dark-accent/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-20%] w-[60%] h-[60%] rounded-full bg-github-light-purple/10 dark:bg-github-dark-purple/5 blur-[120px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, cubicBezier: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md glass-panel custom-shadow rounded-2xl p-8 border border-github-light-border/50 dark:border-github-dark-border/40 relative z-10"
      >
        <Outlet />
      </motion.div>
    </div>
  );
}
export { AuthLayout };
