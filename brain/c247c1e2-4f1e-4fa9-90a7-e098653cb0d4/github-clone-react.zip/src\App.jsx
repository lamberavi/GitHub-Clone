import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import { Toaster } from 'react-hot-toast';
import { store } from './redux/store';
import { AuthProvider } from './context/AuthContext';
import AppRoutes from './routes/AppRoutes';

function App() {
  return (
    <Provider store={store}>
      <BrowserRouter>
        <AuthProvider>
          <AppRoutes />
          <Toaster 
            position="bottom-right"
            toastOptions={{
              duration: 3000,
              style: {
                background: '#161b22',
                color: '#e6edf3',
                border: '1px solid #30363d',
                fontSize: '13px',
                fontFamily: 'Plus Jakarta Sans, sans-serif'
              }
            }}
          />
        </AuthProvider>
      </BrowserRouter>
    </Provider>
  );
}

export default App;
