import mongoose from 'mongoose';

export const connectDB = async () => {
  // Disable command buffering globally so queries fail fast instead of hanging on timeouts
  mongoose.set('bufferCommands', false);
  
  try {
    const mongoURI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/github-clone';
    const conn = await mongoose.connect(mongoURI, {
      serverSelectionTimeoutMS: 3000 // Timeout in 3s if MongoDB is offline
    });
    console.log(`MongoDB Connected: ${conn.connection.host}`);
    return true;
  } catch (error) {
    console.error(`MongoDB Connection Error: ${error.message}`);
    console.log('MongoDB server offline. Server starting with simulated local/in-memory DB fallback.');
    return false;
  }
};

export default connectDB;
