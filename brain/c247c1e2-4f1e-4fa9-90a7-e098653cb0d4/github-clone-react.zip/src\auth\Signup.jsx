import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Github, UserPlus } from 'lucide-react';
import Input from '../components/common/Input';
import Button from '../components/common/Button';
import useAuth from '../hooks/useAuth';
import { signupSchema } from '../utils/validators';

export default function Signup() {
  const navigate = useNavigate();
  const { signup } = useAuth();
  const [isLoading, setIsLoading] = useState(false);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors }
  } = useForm({
    resolver: zodResolver(signupSchema)
  });

  const passwordVal = watch('password', '');

  // Calculate password strength score (0 to 4)
  const getPasswordStrength = (pwd) => {
    let score = 0;
    if (!pwd) return score;
    if (pwd.length >= 6) score++;
    if (/[A-Z]/.test(pwd)) score++;
    if (/[a-z]/.test(pwd)) score++;
    if (/[0-9]/.test(pwd)) score++;
    return score;
  };

  const strengthScore = getPasswordStrength(passwordVal);

  const getStrengthMeta = (score) => {
    if (score === 0) return { label: 'None', color: 'bg-neutral-200 w-0' };
    if (score <= 2) return { label: 'Weak', color: 'bg-red-500 w-1/3' };
    if (score === 3) return { label: 'Medium', color: 'bg-amber-500 w-2/3' };
    return { label: 'Strong', color: 'bg-emerald-500 w-full' };
  };

  const strengthMeta = getStrengthMeta(strengthScore);

  const onSubmit = async (data) => {
    setIsLoading(true);
    try {
      await signup(
        data.email, 
        data.password, 
        data.username, 
        data.firstName, 
        data.lastName
      );
      navigate('/verify-email');
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-h-[85vh] overflow-y-auto pr-1">
      
      {/* Header Info */}
      <div className="text-center space-y-2">
        <Link to="/" className="inline-flex justify-center mb-2">
          <Github className="w-10 h-10 text-github-light-text dark:text-github-dark-text animate-pulse-slow" />
        </Link>
        <h2 className="text-2xl font-bold tracking-tight">Create your account</h2>
        <p className="text-sm text-github-light-textMuted dark:text-github-dark-textMuted">
          Already have an account?{' '}
          <Link to="/login" className="font-semibold text-github-light-accent dark:text-github-dark-accent hover:underline">
            Sign in
          </Link>
        </p>
      </div>

      {/* Main Form */}
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-3.5">
        
        {/* Name Fields Grid */}
        <div className="grid grid-cols-2 gap-3">
          <Input
            label="First Name"
            placeholder="First Name"
            {...register('firstName')}
            error={errors.firstName?.message}
            disabled={isLoading}
          />
          <Input
            label="Last Name"
            placeholder="Last Name"
            {...register('lastName')}
            error={errors.lastName?.message}
            disabled={isLoading}
          />
        </div>

        <Input
          label="Username"
          placeholder="e.g. ravil_dev"
          {...register('username')}
          error={errors.username?.message}
          disabled={isLoading}
        />

        <Input
          label="Email address"
          type="email"
          placeholder="e.g. ravil@antigravity.io"
          {...register('email')}
          error={errors.email?.message}
          disabled={isLoading}
        />

        {/* Password input + Strength indicator */}
        <div className="space-y-1">
          <Input
            label="Password"
            type="password"
            placeholder="At least 6 characters"
            {...register('password')}
            error={errors.password?.message}
            disabled={isLoading}
          />
          {passwordVal && (
            <div className="space-y-1 px-1">
              <div className="h-1.5 w-full bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
                <div className={`h-full transition-all duration-300 ${strengthMeta.color}`} />
              </div>
              <div className="flex justify-between items-center text-[10px] font-bold text-github-light-textMuted dark:text-github-dark-textMuted uppercase">
                <span>Strength: {strengthMeta.label}</span>
                <span>(requires: caps, lowercase, numbers)</span>
              </div>
            </div>
          )}
        </div>

        <Input
          label="Confirm Password"
          type="password"
          placeholder="••••••••"
          {...register('confirmPassword')}
          error={errors.confirmPassword?.message}
          disabled={isLoading}
        />

        <div className="flex items-start">
          <input
            id="terms"
            name="terms"
            type="checkbox"
            required
            className="mt-1 h-4 w-4 rounded border-github-light-border dark:border-github-dark-border bg-github-light-bg dark:bg-github-dark-bg text-github-light-accent dark:text-github-dark-accent cursor-pointer"
          />
          <label htmlFor="terms" className="ml-2 block text-xs leading-normal select-none text-github-light-textMuted dark:text-github-dark-textMuted">
            I accept the{' '}
            <a href="#" className="text-github-light-accent dark:text-github-dark-accent hover:underline">Terms of Service</a>{' '}
            and{' '}
            <a href="#" className="text-github-light-accent dark:text-github-dark-accent hover:underline">Privacy Policy</a>.
          </label>
        </div>

        <Button 
          type="submit" 
          className="w-full py-2.5 mt-2" 
          isLoading={isLoading}
          icon={UserPlus}
        >
          Create Account
        </Button>
      </form>

    </div>
  );
}
export { Signup };
