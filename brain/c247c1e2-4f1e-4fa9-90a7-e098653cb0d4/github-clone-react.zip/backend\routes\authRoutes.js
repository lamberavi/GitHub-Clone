import express from 'express';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import nodemailer from 'nodemailer';
import User from '../models/User.js';
import protect from '../middleware/authMiddleware.js';

const router = express.Router();

// Helper to generate JWT and set Http-Only Cookie
const generateTokenAndSetCookie = (res, userId) => {
  const token = jwt.sign({ id: userId }, process.env.JWT_SECRET || 'antigravity-jwt-secret-key-98124', {
    expiresIn: '30d'
  });

  res.cookie('token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax', // Lax supports development ports
    maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
  });

  return token;
};

// NodeMailer Transporter Configuration Helper
const getTransporter = async () => {
  if (process.env.SMTP_HOST && process.env.SMTP_USER) {
    return nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });
  }

  // Local development fallback: Single pre-verified Ethereal transporter to avoid delays
  return nodemailer.createTransport({
    host: 'smtp.ethereal.email',
    port: 587,
    secure: false,
    auth: {
      user: 'kiley.schmidt92@ethereal.email',
      pass: 'NszgX7Q28a3HagqSjQ'
    }
  });
};

// HTML Email Layout Generator
const getVerificationEmailTemplate = (username, link) => `
<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      background-color: #0D1117;
      color: #C9D1D9;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
      margin: 0;
      padding: 0;
    }
    .wrapper {
      max-width: 580px;
      margin: 30px auto;
      background-color: #161B22;
      border: 1px border #30363D;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 8px 24px rgba(0,0,0,0.4);
    }
    .header {
      background-color: #0D1117;
      padding: 30px;
      text-align: center;
      border-bottom: 1px solid #30363D;
    }
    .content {
      padding: 40px 30px;
      line-height: 1.6;
    }
    h1 {
      color: #FFFFFF;
      font-size: 22px;
      font-weight: 800;
      margin-top: 0;
    }
    p {
      font-size: 14px;
      color: #8B949E;
    }
    .btn-container {
      margin: 30px 0;
      text-align: center;
    }
    .btn {
      display: inline-block;
      background-color: #238636;
      color: #FFFFFF !important;
      text-decoration: none;
      padding: 12px 24px;
      font-size: 14px;
      font-weight: 700;
      border-radius: 6px;
      transition: background-color 0.2s;
    }
    .btn:hover {
      background-color: #2ea44f;
    }
    .footer {
      padding: 20px 30px;
      background-color: #0D1117;
      border-top: 1px solid #30363D;
      font-size: 11px;
      color: #8B949E;
      text-align: center;
    }
    .link-backup {
      word-break: break-all;
      font-size: 12px;
      color: #58A6FF;
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="header">
      <svg height="36" viewBox="0 0 16 16" version="1.1" width="36" fill="#FFFFFF" aria-hidden="true">
        <path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"></path>
      </svg>
    </div>
    <div class="content">
      <h1>Verify your email address</h1>
      <p>Hi @${username},</p>
      <p>Thanks for creating an account on GitHub Clone! Please verify your email by clicking the button below.</p>
      <div class="btn-container">
        <a href="${link}" class="btn" target="_blank">Verify Email</a>
      </div>
      <p>This verification link will expire in 30 minutes.</p>
      <p>If you did not sign up for this account, you can safely ignore this email.</p>
      <hr style="border: 0; border-top: 1px solid #30363D; margin: 25px 0;">
      <p style="font-size: 12px;">Or copy and paste this URL into your browser:</p>
      <p class="link-backup">${link}</p>
    </div>
    <div class="footer">
      © ${new Date().getFullYear()} GitHub Clone. Built for portfolio showcase.
    </div>
  </div>
</body>
</html>
`;

// Helper to send verification email
const sendVerificationEmail = async (email, username, token) => {
  const link = `http://localhost:5173/verify-email?token=${token}`;
  const template = getVerificationEmailTemplate(username, link);

  const transporter = await getTransporter();
  const info = await transporter.sendMail({
    from: '"GitHub Clone" <noreply@githubclone.local>',
    to: email,
    subject: 'Please verify your email address',
    html: template
  });

  // Log link in development console so the developer can click it instantly
  console.log('----------------------------------------');
  console.log(`Verification Email Sent to ${email}`);
  console.log(`Link: ${link}`);
  const previewUrl = nodemailer.getTestMessageUrl(info);
  if (previewUrl) {
    console.log(`Ethereal Inbox Preview: ${previewUrl}`);
  }
  console.log('----------------------------------------');
  return info;
};

// @desc    Register a new user (with cryptographically secure verification token)
// @route   POST /api/auth/register
// @access  Public
router.post('/register', async (req, res) => {
  try {
    const { uid, email, username, firstName, lastName, photo, provider } = req.body;

    if (!uid || !email || !username) {
      return res.status(400).json({ message: 'UID, Email, and Username are required' });
    }

    // Check if user already exists
    let user = await User.findOne({ $or: [{ uid }, { email }, { username }] });
    if (user) {
      return res.status(400).json({ message: 'User with this UID, Email, or Username already exists' });
    }

    // Generate random 32-bytes token
    const rawToken = crypto.randomBytes(32).toString('hex');
    const hashedToken = crypto.createHash('sha256').update(rawToken).digest('hex');
    const tokenExpiry = Date.now() + 30 * 60 * 1000; // 30 mins

    user = await User.create({
      uid,
      email,
      username,
      firstName,
      lastName,
      photo: photo || undefined,
      provider: provider || 'email',
      isVerified: false,
      verificationToken: hashedToken,
      verificationTokenExpiry: tokenExpiry,
      lastLogin: new Date()
    });

    // Send the email
    try {
      await sendVerificationEmail(email, username, rawToken);
    } catch (mailErr) {
      console.warn('Mail Dispatch Failed, continuing registration flow in sandbox mode:', mailErr.message);
    }

    generateTokenAndSetCookie(res, user._id);

    res.status(201).json({
      success: true,
      user: {
        id: user._id,
        uid: user.uid,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        photo: user.photo,
        provider: user.provider,
        role: user.role,
        isVerified: user.isVerified
      }
    });
  } catch (error) {
    res.status(500).json({ message: `Registration Error: ${error.message}` });
  }
});

// @desc    Verify email address using secure token
// @route   POST /api/auth/verify-email
// @access  Public
router.post('/verify-email', async (req, res) => {
  try {
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({ message: 'Verification token is required' });
    }

    // Hash parameter token to match stored values
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

    const user = await User.findOne({
      verificationToken: hashedToken,
      verificationTokenExpiry: { $gt: Date.now() }
    });

    if (!user) {
      return res.status(400).json({ message: 'Verification link is invalid or has expired.' });
    }

    // Mark email as verified and clear token entries
    user.isVerified = true;
    user.verificationToken = undefined;
    user.verificationTokenExpiry = undefined;
    await user.save();

    res.status(200).json({
      success: true,
      message: 'Email address verified successfully!'
    });
  } catch (error) {
    res.status(500).json({ message: `Email Verification Error: ${error.message}` });
  }
});

// @desc    Resend Verification Link with rate limiting cooldown check
// @route   POST /api/auth/resend-verification
// @access  Public
router.post('/resend-verification', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: 'Email address is required' });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: 'No registered user found with this email.' });
    }

    if (user.isVerified) {
      return res.status(400).json({ message: 'This email is already verified.' });
    }

    // Generate new token
    const rawToken = crypto.randomBytes(32).toString('hex');
    const hashedToken = crypto.createHash('sha256').update(rawToken).digest('hex');
    const tokenExpiry = Date.now() + 30 * 60 * 1000; // 30 mins

    user.verificationToken = hashedToken;
    user.verificationTokenExpiry = tokenExpiry;
    await user.save();

    await sendVerificationEmail(email, user.username, rawToken);

    res.status(200).json({
      success: true,
      message: 'New verification email dispatched successfully.'
    });
  } catch (error) {
    res.status(500).json({ message: `Resend Error: ${error.message}` });
  }
});

// @desc    Google Sign In (sync/create from Firebase OAuth popup)
// @route   POST /api/auth/google
// @access  Public
router.post('/google', async (req, res) => {
  try {
    const { uid, email, displayName, photoURL } = req.body;

    if (!uid || !email) {
      return res.status(400).json({ message: 'UID and Email are required' });
    }

    // Check if user already exists
    let user = await User.findOne({ uid });

    if (!user) {
      // Create new user if not exist
      const usernameFallback = email.split('@')[0] + Math.floor(Math.random() * 1000);
      const nameParts = displayName ? displayName.split(' ') : ['', ''];
      
      user = await User.create({
        uid,
        email,
        username: usernameFallback,
        firstName: nameParts[0] || 'GoogleUser',
        lastName: nameParts.slice(1).join(' ') || '',
        photo: photoURL || undefined,
        provider: 'google',
        isVerified: true, // Google accounts are auto-verified
        lastLogin: new Date()
      });
    } else {
      user.lastLogin = new Date();
      await user.save();
    }

    generateTokenAndSetCookie(res, user._id);

    res.status(200).json({
      success: true,
      user: {
        id: user._id,
        uid: user.uid,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        photo: user.photo,
        provider: user.provider,
        role: user.role,
        isVerified: user.isVerified
      }
    });
  } catch (error) {
    res.status(500).json({ message: `Google Sync Error: ${error.message}` });
  }
});

// @desc    Login User Session (verifies verified flag and sets cookie)
// @route   POST /api/auth/login
// @access  Public
router.post('/login', async (req, res) => {
  try {
    const { uid } = req.body;
    
    if (!uid) {
      return res.status(400).json({ message: 'Session UID required' });
    }

    const user = await User.findOne({ uid });
    if (!user) {
      return res.status(404).json({ message: 'No registered user found with this UID' });
    }

    // Enforce login restriction (Phase 10)
    if (!user.isVerified) {
      return res.status(403).json({
        isUnverified: true,
        email: user.email,
        message: 'Your email address is not verified. Please verify your email before logging in.'
      });
    }

    user.lastLogin = new Date();
    await user.save();

    generateTokenAndSetCookie(res, user._id);

    res.status(200).json({
      success: true,
      user
    });
  } catch (error) {
    res.status(500).json({ message: `Login Error: ${error.message}` });
  }
});

// @desc    Logout User / Clear Cookie
// @route   POST /api/auth/logout
// @access  Private (but accessible for reset)
router.post('/logout', (req, res) => {
  res.cookie('token', '', {
    httpOnly: true,
    expires: new Date(0),
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax'
  });
  res.status(200).json({ success: true, message: 'Logged out successfully' });
});

// @desc    Get Current User Profile
// @route   GET /api/user/profile
// @access  Private
router.get('/profile', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.status(200).json({ success: true, user });
  } catch (error) {
    res.status(500).json({ message: `Profile Fetch Error: ${error.message}` });
  }
});

// @desc    Update User Profile
// @route   PUT /api/user/update
// @access  Private
router.put('/update', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.firstName = req.body.firstName || user.firstName;
    user.lastName = req.body.lastName || user.lastName;
    user.username = req.body.username || user.username;
    user.photo = req.body.photo || user.photo;

    const updatedUser = await user.save();

    res.status(200).json({
      success: true,
      user: updatedUser
    });
  } catch (error) {
    res.status(500).json({ message: `Update Error: ${error.message}` });
  }
});

export default router;
