import React from 'react';
import { ArrowRight } from 'lucide-react';

export default function CTAButton({ text = "Read Case Study", href = "#" }) {
  return (
    <a 
      href={href} 
      className="inline-flex items-center gap-1.5 text-xs font-black text-github-dark-accent hover:text-white transition-all group/cta pt-1 cursor-pointer select-none"
    >
      <span className="relative py-0.5">
        {text}
        <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-github-dark-accent transition-all duration-300 group-hover/cta:w-full" />
      </span>
      <ArrowRight size={13} className="transform transition-transform duration-300 group-hover/cta:translate-x-1" />
    </a>
  );
}
export { CTAButton };
