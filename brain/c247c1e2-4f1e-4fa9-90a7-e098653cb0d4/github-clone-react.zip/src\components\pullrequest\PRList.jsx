import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { GitPullRequest, GitMerge, Plus, ArrowRight, MessageSquare, Files, User, X } from 'lucide-react';
import Button from '../common/Button';
import Badge from '../common/Badge';
import Modal from '../common/Modal';
import Input from '../common/Input';
import { addPullRequest, mergePullRequest } from '../../redux/slices/repoSlice';

export default function PRList({ prs = [], branches = [], repoId }) {
  const dispatch = useDispatch();

  const [activeTab, setActiveTab] = useState('open'); // open, merged
  
  // PR Creation state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newPR, setNewPR] = useState({ title: '', source: branches[1] || 'dev', target: 'main' });

  // Single PR details state
  const [selectedPR, setSelectedPR] = useState(null);
  const [prViewTab, setPrViewTab] = useState('conversation'); // conversation, files

  const handleCreatePR = (e) => {
    e.preventDefault();
    if (!newPR.title.trim()) return;

    dispatch(addPullRequest({
      title: newPR.title,
      sourceBranch: newPR.source,
      targetBranch: newPR.target,
      fileDiffs: [
        {
          filepath: 'src/components/Sidebar.jsx',
          additions: 12,
          deletions: 4,
          content: `@@ -4,4 +4,12 @@\n export default function Sidebar() {\n+  const [collapsed, setCollapsed] = useState(false);\n   return (\n-    <aside className="w-64 bg-slate-900 border-r border-slate-800">\n+    <aside className={\`bg-slate-900 border-r border-slate-800 transition-all duration-300 \${collapsed ? 'w-20' : 'w-64'}\`}>\n+      <button onClick={() => setCollapsed(!collapsed)} className="p-2 hover:bg-slate-800">\n+        Collapse\n+      </button>\n       <nav className="p-4 space-y-2">\n         {/* Link list items */}`
        }
      ]
    }));

    setNewPR({ title: '', source: branches[1] || 'dev', target: 'main' });
    setIsCreateModalOpen(false);
  };

  const handleMergeClick = (id) => {
    dispatch(mergePullRequest(id));
    if (selectedPR && selectedPR.id === id) {
      setSelectedPR((prev) => ({ ...prev, status: 'merged' }));
    }
  };

  const filteredPRs = prs.filter(pr => pr.status === activeTab);

  return (
    <div className="space-y-4">
      
      {!selectedPR ? (
        <>
          {/* 1. Header controls */}
          <div className="flex justify-between items-center flex-wrap gap-3">
            <h3 className="font-bold text-sm text-github-light-textMuted dark:text-github-dark-textMuted">Pull Requests</h3>
            <Button icon={Plus} onClick={() => setIsCreateModalOpen(true)}>
              New Pull Request
            </Button>
          </div>

          {/* Tab switches */}
          <div className="flex border-b border-github-light-border/60 dark:border-github-dark-border/60">
            <button
              onClick={() => setActiveTab('open')}
              className={`px-4 py-2 text-xs font-bold border-b-2 -mb-[2px] flex items-center gap-1.5 ${
                activeTab === 'open'
                  ? 'border-github-light-accent dark:border-github-dark-accent text-github-light-text dark:text-github-dark-text'
                  : 'border-transparent text-github-light-textMuted dark:text-github-dark-textMuted hover:text-github-light-text'
              }`}
            >
              <GitPullRequest size={14} className="text-github-light-success dark:text-github-dark-success" />
              <span>{prs.filter(p => p.status === 'open').length} Open</span>
            </button>
            <button
              onClick={() => setActiveTab('merged')}
              className={`px-4 py-2 text-xs font-bold border-b-2 -mb-[2px] flex items-center gap-1.5 ${
                activeTab === 'merged'
                  ? 'border-github-light-accent dark:border-github-dark-accent text-github-light-text dark:text-github-dark-text'
                  : 'border-transparent text-github-light-textMuted dark:text-github-dark-textMuted hover:text-github-light-text'
              }`}
            >
              <GitMerge size={14} className="text-github-light-purple dark:text-github-dark-purple" />
              <span>{prs.filter(p => p.status === 'merged').length} Merged</span>
            </button>
          </div>

          {/* PR Listing items */}
          <div className="glass-panel border border-github-light-border/60 dark:border-github-dark-border/60 rounded-xl overflow-hidden divide-y divide-github-light-border/40 dark:divide-github-dark-border/45 custom-shadow">
            {filteredPRs.length > 0 ? (
              filteredPRs.map((pr) => (
                <button
                  key={pr.id}
                  onClick={() => { setSelectedPR(pr); setPrViewTab('conversation'); }}
                  className="w-full text-left p-4 hover:bg-neutral-100 dark:hover:bg-neutral-850/40 flex items-start justify-between gap-4 transition-colors"
                >
                  <div className="min-w-0 flex-1 space-y-1">
                    <span className="font-semibold text-sm hover:text-github-light-accent dark:hover:text-github-dark-accent">
                      {pr.title}
                    </span>
                    <p className="text-[10px] text-github-light-textMuted dark:text-github-dark-textMuted">
                      #{pr.number} opened {new Date(pr.date).toLocaleDateString()} by @{pr.author} · {pr.sourceBranch} → {pr.targetBranch}
                    </p>
                  </div>

                  <div className="flex gap-2 items-center">
                    <Badge variant={pr.status === 'open' ? 'success' : 'purple'} size="sm">
                      {pr.status === 'open' ? 'Open' : 'Merged'}
                    </Badge>
                  </div>
                </button>
              ))
            ) : (
              <div className="p-16 text-center text-xs text-github-light-textMuted dark:text-github-dark-textMuted">
                No pull requests found.
              </div>
            )}
          </div>
        </>
      ) : (
        /* 2. PR Detail view */
        <div className="space-y-6 animate-fade-in">
          
          {/* Header */}
          <div className="border-b border-github-light-border/60 dark:border-github-dark-border/60 pb-4 space-y-2">
            <div className="flex justify-between items-start gap-4">
              <h2 className="text-lg font-bold">
                {selectedPR.title} <span className="font-mono text-github-light-textMuted dark:text-github-dark-textMuted">#{selectedPR.number}</span>
              </h2>
              <button 
                onClick={() => setSelectedPR(null)}
                className="p-1 hover:bg-neutral-200 dark:hover:bg-neutral-800 rounded-lg text-github-light-textMuted dark:text-github-dark-textMuted"
              >
                <X size={18} />
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs">
              <Badge variant={selectedPR.status === 'open' ? 'success' : 'purple'}>
                {selectedPR.status === 'open' ? 'Open' : 'Merged'}
              </Badge>
              <span className="text-github-light-textMuted dark:text-github-dark-textMuted font-semibold">
                @{selectedPR.author} wants to merge commits into <code className="px-1.5 py-0.5 rounded bg-neutral-150 dark:bg-github-dark-border">{selectedPR.targetBranch}</code> from <code className="px-1.5 py-0.5 rounded bg-neutral-150 dark:bg-github-dark-border">{selectedPR.sourceBranch}</code>
              </span>
            </div>
          </div>

          {/* Sub Navigation tabs */}
          <div className="flex border-b border-github-light-border/60 dark:border-github-dark-border/60">
            <button
              onClick={() => setPrViewTab('conversation')}
              className={`px-4 py-2 text-xs font-bold border-b-2 -mb-[2px] flex items-center gap-1.5 ${
                prViewTab === 'conversation'
                  ? 'border-github-light-accent dark:border-github-dark-accent text-github-light-text dark:text-github-dark-text'
                  : 'border-transparent text-github-light-textMuted dark:text-github-dark-textMuted hover:text-github-light-text'
              }`}
            >
              <MessageSquare size={13} />
              <span>Conversation</span>
            </button>
            <button
              onClick={() => setPrViewTab('files')}
              className={`px-4 py-2 text-xs font-bold border-b-2 -mb-[2px] flex items-center gap-1.5 ${
                prViewTab === 'files'
                  ? 'border-github-light-accent dark:border-github-dark-accent text-github-light-text dark:text-github-dark-text'
                  : 'border-transparent text-github-light-textMuted dark:text-github-dark-textMuted hover:text-github-light-text'
              }`}
            >
              <Files size={13} />
              <span>Files Changed ({selectedPR.fileDiffs?.length || 0})</span>
            </button>
          </div>

          {/* Tab content */}
          {prViewTab === 'conversation' ? (
            <div className="space-y-6">
              
              {/* Opener info */}
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-neutral-200 dark:bg-github-dark-border flex items-center justify-center font-bold text-xs">
                  {selectedPR.author[0].toUpperCase()}
                </div>
                <div className="flex-1 glass-panel border border-github-light-border dark:border-github-dark-border rounded-xl p-4 space-y-2">
                  <div className="flex justify-between text-2xs text-github-light-textMuted dark:text-github-dark-textMuted font-bold">
                    <span>@{selectedPR.author} commented</span>
                    <span>{new Date(selectedPR.date).toLocaleDateString()}</span>
                  </div>
                  <p className="text-sm">
                    This pull request introduces clean animations and fixes theme flashes on dashboard widgets. Please review files changed logs.
                  </p>
                </div>
              </div>

              {/* Merge Actions panel */}
              <div className="glass-panel p-5 rounded-xl border border-github-light-border dark:border-github-dark-border custom-shadow flex items-start gap-4">
                <div className={`p-2.5 rounded-lg text-white ${
                  selectedPR.status === 'merged' ? 'bg-github-light-purple dark:bg-github-dark-purple' : 'bg-github-light-success dark:bg-github-dark-success'
                }`}>
                  {selectedPR.status === 'merged' ? <GitMerge size={20} /> : <GitPullRequest size={20} />}
                </div>

                <div className="space-y-1.5 flex-1 min-w-0">
                  <h4 className="text-sm font-bold">
                    {selectedPR.status === 'merged' 
                      ? 'Pull request successfully merged' 
                      : 'This branch has no conflicts with the base branch'}
                  </h4>
                  <p className="text-xs text-github-light-textMuted dark:text-github-dark-textMuted leading-normal">
                    {selectedPR.status === 'merged'
                      ? 'Commits have been incorporated into the main production timeline.'
                      : 'Merging can be performed automatically. Always check unit test workflows beforehand.'}
                  </p>
                  
                  {selectedPR.status === 'open' && (
                    <Button 
                      size="sm" 
                      variant="success" 
                      icon={GitMerge}
                      onClick={() => handleMergeClick(selectedPR.id)}
                      className="mt-2"
                    >
                      Merge pull request
                    </Button>
                  )}
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <Button variant="outline" size="sm" onClick={() => setSelectedPR(null)}>
                  Back to List
                </Button>
              </div>

            </div>
          ) : (
            /* Visual code diff visualizer */
            <div className="space-y-6">
              {selectedPR.fileDiffs?.map((diff, dfIdx) => (
                <div key={dfIdx} className="border border-github-light-border dark:border-github-dark-border rounded-xl overflow-hidden shadow-premium bg-github-light-bg dark:bg-github-dark-bg">
                  <div className="px-4 py-2.5 bg-neutral-50 dark:bg-github-dark-sidebar/40 border-b border-github-light-border/60 dark:border-github-dark-border/60 font-mono text-xs flex justify-between">
                    <span>{diff.filepath}</span>
                    <span className="text-[10px] text-github-light-success dark:text-github-dark-success">
                      +{diff.additions} -{diff.deletions}
                    </span>
                  </div>

                  {/* Diff highlight viewer */}
                  <pre className="p-4 overflow-x-auto text-[11px] font-mono leading-relaxed bg-neutral-950 text-slate-200">
                    <code>
                      {diff.content.split('\n').map((line, lIdx) => {
                        const isAdd = line.startsWith('+');
                        const isDel = line.startsWith('-');
                        const isMeta = line.startsWith('@@');

                        let lineClass = 'text-slate-400';
                        if (isAdd) lineClass = 'bg-emerald-950/70 text-emerald-300 font-semibold px-1 rounded-sm';
                        else if (isDel) lineClass = 'bg-red-950/80 text-red-300 font-semibold px-1 rounded-sm';
                        else if (isMeta) lineClass = 'text-cyan-400 opacity-80';

                        return (
                          <div key={lIdx} className={`${lineClass} select-text py-0.5`}>
                            {line}
                          </div>
                        );
                      })}
                    </code>
                  </pre>
                </div>
              ))}
            </div>
          )}

        </div>
      )}

      {/* 3. New PR Dialog Modal */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Open a new pull request"
        footer={
          <>
            <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreatePR} isDisabled={!newPR.title.trim()}>
              Create Pull Request
            </Button>
          </>
        }
      >
        <form onSubmit={handleCreatePR} className="space-y-4">
          <Input
            label="PR Title"
            name="title"
            placeholder="e.g. feat: integrate dark mode toggles in navbar"
            value={newPR.title}
            onChange={(e) => setNewPR({ ...newPR, title: e.target.value })}
            required
            autoFocus
          />

          <div className="grid grid-cols-2 gap-3 items-center pt-2">
            <div className="flex flex-col gap-1.5">
              <label className="text-2xs font-bold text-github-light-textMuted dark:text-github-dark-textMuted uppercase">Source (compare)</label>
              <select
                value={newPR.source}
                onChange={(e) => setNewPR({ ...newPR, source: e.target.value })}
                className="px-3 py-2 text-sm bg-github-light-bg dark:bg-github-dark-bg border border-github-light-border dark:border-github-dark-border rounded-lg outline-none cursor-pointer"
              >
                {branches.filter(b => b !== 'main').map(b => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-2xs font-bold text-github-light-textMuted dark:text-github-dark-textMuted uppercase">Target (base)</label>
              <select
                value={newPR.target}
                onChange={(e) => setNewPR({ ...newPR, target: e.target.value })}
                className="px-3 py-2 text-sm bg-github-light-bg dark:bg-github-dark-bg border border-github-light-border dark:border-github-dark-border rounded-lg outline-none cursor-pointer"
              >
                <option value="main">main</option>
              </select>
            </div>
          </div>
        </form>
      </Modal>

    </div>
  );
}
