import React from 'react';
import useAuth from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';

export default function GoogleLogin({ disabled, onLoadChange }) {
  const { googleLogin } = useAuth();
  const navigate = useNavigate();

  const handleGoogleSignIn = async () => {
    if (onLoadChange) onLoadChange(true);
    try {
      await googleLogin();
      navigate('/dashboard');
    } catch (err) {
      console.error(err);
    } finally {
      if (onLoadChange) onLoadChange(false);
    }
  };

  return (
    <button 
      type="button" 
      onClick={handleGoogleSignIn}
      disabled={disabled}
      className="w-full border border-github-light-border dark:border-github-dark-border hover:bg-neutral-100 dark:hover:bg-neutral-800 text-sm font-semibold py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
    >
      <span className="text-sm">🌐</span>
      <span>Continue with Google</span>
    </button>
  );
}
export { GoogleLogin };
