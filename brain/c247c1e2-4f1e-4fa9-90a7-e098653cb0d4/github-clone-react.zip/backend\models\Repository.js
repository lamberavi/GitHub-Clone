import mongoose from 'mongoose';

const repositorySchema = new mongoose.Schema(
  {
    repoId: {
      type: String,
      required: true,
      unique: true,
      index: true
    },
    ownerId: {
      type: String, // UID of user
      required: true,
      index: true
    },
    repoName: {
      type: String,
      required: true,
      trim: true
    },
    description: {
      type: String,
      default: ''
    },
    visibility: {
      type: String,
      enum: ['public', 'private'],
      default: 'public',
      index: true
    },
    language: {
      type: String,
      default: 'JavaScript'
    },
    stars: {
      type: Number,
      default: 0
    },
    forks: {
      type: Number,
      default: 0
    },
    watchers: {
      type: Number,
      default: 1
    },
    openIssues: {
      type: Number,
      default: 0
    },
    defaultBranch: {
      type: String,
      default: 'main'
    },
    topics: {
      type: [String],
      default: []
    },
    hasReadme: {
      type: Boolean,
      default: true
    },
    hasGitignore: {
      type: Boolean,
      default: false
    },
    license: {
      type: String,
      default: 'None'
    },
    isPinned: {
      type: Boolean,
      default: false
    },
    isArchived: {
      type: Boolean,
      default: false
    }
  },
  {
    timestamps: true
  }
);

export const Repository = mongoose.model('Repository', repositorySchema);
export default Repository;
