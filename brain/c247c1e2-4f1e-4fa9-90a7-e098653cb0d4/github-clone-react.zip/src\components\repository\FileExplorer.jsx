import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Folder, FileText, ArrowLeft, Terminal, FileCode } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { pushPath, popPath, setPath, setSelectedFile } from '../../redux/slices/repoSlice';

export default function FileExplorer({ filesNode, commits = [] }) {
  const dispatch = useDispatch();
  const { currentPath } = useSelector((state) => state.repos);

  // Helper to traverse the files tree according to the currentPath array
  const getCurrentDirectory = () => {
    let current = filesNode;
    for (const folder of currentPath) {
      if (current.children) {
        const found = current.children.find(
          (c) => c.type === 'dir' && c.name === folder
        );
        if (found) current = found;
      }
    }
    return current;
  };

  const currentDir = getCurrentDirectory();
  const latestCommit = commits[0] || { author: 'ravil', message: 'Update codebase files', date: new Date().toISOString() };

  // Find README.md in current directory
  const readmeFile = currentDir.children?.find(
    (c) => c.type === 'file' && c.name.toLowerCase() === 'readme.md'
  );

  const handleNodeClick = (node) => {
    if (node.type === 'dir') {
      dispatch(pushPath(node.name));
    } else {
      // Find language based on file extension
      const ext = node.name.split('.').pop().toLowerCase();
      let language = 'javascript';
      if (ext === 'md') language = 'markdown';
      else if (ext === 'html') language = 'html';
      else if (ext === 'css') language = 'css';
      else if (ext === 'json') language = 'json';

      dispatch(setSelectedFile({
        name: node.name,
        content: node.content,
        language
      }));
    }
  };

  return (
    <div className="space-y-6">
      
      {/* 1. Breadcrumbs */}
      <div className="flex items-center gap-1.5 text-sm font-semibold flex-wrap">
        <button
          onClick={() => dispatch(setPath([]))}
          className="text-github-light-accent dark:text-github-dark-accent hover:underline"
        >
          root
        </button>
        {currentPath.map((folder, index) => (
          <React.Fragment key={index}>
            <span className="text-github-light-textMuted dark:text-github-dark-textMuted">/</span>
            <button
              onClick={() => dispatch(setPath(currentPath.slice(0, index + 1)))}
              className="text-github-light-accent dark:text-github-dark-accent hover:underline"
            >
              {folder}
            </button>
          </React.Fragment>
        ))}
      </div>

      {/* 2. File Explorer Table container */}
      <div className="glass-panel border border-github-light-border/60 dark:border-github-dark-border/60 rounded-xl overflow-hidden custom-shadow">
        
        {/* Latest Commit Bar Header */}
        <div className="px-4 py-3 bg-neutral-50 dark:bg-github-dark-sidebar/40 border-b border-github-light-border/60 dark:border-github-dark-border/60 flex items-center justify-between text-xs flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="font-bold">{latestCommit.author}</span>
            <span className="text-github-light-textMuted dark:text-github-dark-textMuted truncate max-w-sm sm:max-w-md">
              {latestCommit.message}
            </span>
          </div>
          <span className="text-github-light-textMuted dark:text-github-dark-textMuted shrink-0 font-medium">
            {latestCommit.id || 'c1a2b3'} · {new Date(latestCommit.date).toLocaleDateString()}
          </span>
        </div>

        {/* Directory rows list */}
        <div className="divide-y divide-github-light-border/40 dark:divide-github-dark-border/45">
          {currentPath.length > 0 && (
            <button
              onClick={() => dispatch(popPath())}
              className="w-full text-left px-4 py-2.5 text-xs hover:bg-neutral-100 dark:hover:bg-neutral-800/40 text-github-light-accent dark:text-github-dark-accent font-semibold flex items-center gap-2.5"
            >
              <ArrowLeft size={14} />
              <span>.. (Parent Directory)</span>
            </button>
          )}

          {currentDir.children?.map((node) => (
            <button
              key={node.name}
              onClick={() => handleNodeClick(node)}
              className="w-full text-left px-4 py-3 hover:bg-neutral-100 dark:hover:bg-neutral-850/40 flex items-center justify-between text-sm transition-colors group"
            >
              <div className="flex items-center gap-3 min-w-0">
                {node.type === 'dir' ? (
                  <Folder size={18} className="text-blue-450 dark:text-blue-500 shrink-0" />
                ) : node.name.endsWith('.md') ? (
                  <FileText size={18} className="text-github-light-textMuted dark:text-github-dark-textMuted shrink-0" />
                ) : (
                  <FileCode size={18} className="text-github-light-accent dark:text-github-dark-accent shrink-0" />
                )}
                <span className="truncate group-hover:text-github-light-accent dark:group-hover:text-github-dark-accent font-medium">
                  {node.name}
                </span>
              </div>
              <span className="text-xs text-github-light-textMuted dark:text-github-dark-textMuted shrink-0">
                {node.type === 'dir' ? 'Folder' : 'File'}
              </span>
            </button>
          ))}

          {(!currentDir.children || currentDir.children.length === 0) && (
            <div className="p-8 text-center text-xs text-github-light-textMuted dark:text-github-dark-textMuted">
              Empty folder repository.
            </div>
          )}
        </div>
      </div>

      {/* 3. README Markdown Box */}
      {readmeFile && (
        <div className="glass-panel border border-github-light-border/60 dark:border-github-dark-border/60 rounded-xl overflow-hidden custom-shadow">
          <div className="px-4 py-3 bg-neutral-50 dark:bg-github-dark-sidebar/40 border-b border-github-light-border/60 dark:border-github-dark-border/60 font-semibold text-xs flex items-center gap-2">
            <FileText size={14} className="text-github-light-textMuted dark:text-github-dark-textMuted" />
            <span>README.md</span>
          </div>
          <div className="p-6 md:p-8 overflow-x-auto prose dark:prose-invert max-w-none text-sm text-github-light-text/90 dark:text-github-dark-text/90">
            <ReactMarkdown>{readmeFile.content}</ReactMarkdown>
          </div>
        </div>
      )}

    </div>
  );
}
