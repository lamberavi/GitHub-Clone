import React, { useRef, useState } from 'react';

export default function CardSpotlight({ children, className = "" }) {
  const containerRef = useRef(null);
  const [coords, setCoords] = useState({ x: 0, y: 0 });
  const [opacity, setOpacity] = useState(0);

  const handleMouseMove = (e) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    setCoords({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setOpacity(1)}
      onMouseLeave={() => setOpacity(0)}
      className={`relative overflow-hidden ${className}`}
      style={{
        '--mouse-x': `${coords.x}px`,
        '--mouse-y': `${coords.y}px`
      }}
    >
      {/* Dynamic Cursor Spotlight Overlay */}
      <div 
        className="absolute pointer-events-none transition-opacity duration-300 z-15 rounded-full"
        style={{
          width: '300px',
          height: '300px',
          background: 'radial-gradient(circle, rgba(88, 166, 255, 0.08) 0%, transparent 75%)',
          left: `${coords.x - 150}px`,
          top: `${coords.y - 150}px`,
          opacity: opacity
        }}
      />
      {children}
    </div>
  );
}
export { CardSpotlight };
