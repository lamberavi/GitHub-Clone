import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Code, Calendar, Users, Cpu, Shield, ArrowRight } from 'lucide-react';
import Button from '../common/Button';

export default function FeatureSection({ activeTab }) {
  const [openAccordion, setOpenAccordion] = useState(0);

  // Reset open accordion on tab switch
  useEffect(() => {
    setOpenAccordion(0);
  }, [activeTab]);

  const contentMap = {
    code: {
      title: 'Write code fluidly in the browser',
      desc: 'Use the integrated Monaco Editor to inspect files, make fast edits, and write commits straight onto branch logs.',
      btnText: 'Open File Explorer',
      items: [
        { label: 'Monaco Editor Integration', details: 'Full syntax highlighting for multiple languages, scroll lines, and visual theme syncs.' },
        { label: 'In-Memory Commits', details: 'Record edits directly on the local git branch without needing CLI terminals.' },
        { label: 'Hierarchical Trees', details: 'Browse folders, subdirectories, and files in a clean sidebar structure.' }
      ],
      mockup: (
        <div className="font-mono text-2xs space-y-3 bg-neutral-950 text-slate-200 p-6 rounded-xl border border-github-light-border/40 dark:border-github-dark-border/40 shadow-lg">
          <p className="text-github-light-textMuted dark:text-github-dark-textMuted">// src/components/Button.jsx</p>
          <p><span className="text-github-light-purple dark:text-github-dark-purple">export const</span> {"Button = ({ children }) => ("}</p>
          <p className="pl-4">&lt;<span className="text-github-light-accent dark:text-github-dark-accent">button</span> className=<span className="text-github-light-success dark:text-github-dark-success">"px-4 py-2 bg-blue-500 rounded"</span>&gt;</p>
          <p className="pl-8">{`{children}`}</p>
          <p className="pl-4">&lt;/<span className="text-github-light-accent dark:text-github-dark-accent">button</span>&gt;</p>
          <p>);</p>
        </div>
      )
    },
    plan: {
      title: 'Track issues and prioritize sprint cycles',
      desc: 'Establish boards to assign tasks, define custom labels, customize priority weights, and review notification triggers.',
      btnText: 'View Issues Board',
      items: [
        { label: 'Custom Bug Labels', details: 'Tag issues with bug, enhancement, or documentation labels for sorting.' },
        { label: 'Priority Weights', details: 'Set priority levels from Low to Critical to guide developer cycles.' },
        { label: 'Interactive Comment Board', details: 'Add replying comments in real time, discuss bug fixes, and resolve threads.' }
      ],
      mockup: (
        <div className="space-y-3 bg-github-light-bg dark:bg-github-dark-sidebar p-5 rounded-xl border border-github-light-border dark:border-github-dark-border shadow-lg">
          <div className="flex items-center justify-between border-b border-github-light-border/40 dark:border-github-dark-border/40 pb-2">
            <span className="text-xs font-bold">Issues Tracking</span>
            <span className="text-3xs px-1.5 py-0.5 rounded bg-github-light-success/15 text-github-light-success dark:text-github-dark-success font-bold">3 Open</span>
          </div>
          <div className="space-y-2">
            <div className="p-2.5 bg-neutral-50 dark:bg-github-dark-bg/60 border border-github-light-border/50 dark:border-github-dark-border/50 rounded-lg text-2xs space-y-1">
              <div className="flex justify-between font-bold">
                <span>#1 Monaco scroll fix</span>
                <span className="text-[9px] text-red-500">Critical</span>
              </div>
              <p className="text-[10px] text-github-light-textMuted dark:text-github-dark-textMuted">Opened by @alex_dev</p>
            </div>
            <div className="p-2.5 bg-neutral-50 dark:bg-github-dark-bg/60 border border-github-light-border/50 dark:border-github-dark-border/50 rounded-lg text-2xs space-y-1">
              <div className="flex justify-between font-bold">
                <span>#2 Document core layout API</span>
                <span className="text-[9px] text-blue-500">Medium</span>
              </div>
              <p className="text-[10px] text-github-light-textMuted dark:text-github-dark-textMuted">Opened by @ravil</p>
            </div>
          </div>
        </div>
      )
    },
    collaborate: {
      title: 'Review pull requests and diff changes',
      desc: 'Verify code additions and deletions line-by-line using visual code diff grids. Resolve threads and merge branches instantly.',
      btnText: 'Explore PR Pipeline',
      items: [
        { label: 'Split Diff Highlighter', details: 'Clear green highlights for additions (+) and red overlays for deletions (-).' },
        { label: 'Merge Approvals', details: 'Verify branch conflicts automatically and click to merge PR branch changes.' },
        { label: 'Branch Compare Picker', details: 'Compare compare-branches directly with the main base branch before building PRs.' }
      ],
      mockup: (
        <div className="font-mono text-2xs bg-neutral-950 text-slate-350 p-5 rounded-xl border border-github-light-border/40 dark:border-github-dark-border/40 shadow-lg space-y-1">
          <p className="text-[10px] text-cyan-400">@@ -4,2 +4,3 @@</p>
          <p className="bg-red-950/80 text-red-300 px-1 font-semibold">- &lt;div className="w-64 bg-slate-900"&gt;</p>
          <p className="bg-emerald-950/70 text-emerald-300 px-1 font-semibold">{"+ <div className={`w-64 bg-slate-900 ${collapsed ? 'w-20' : 'w-64'}`}>"}</p>
          <p className="opacity-80">{"  <Navbar toggle={toggle} />"}</p>
        </div>
      )
    },
    automate: {
      title: 'Monitor live statistics and activity logs',
      desc: 'Observe commits frequency and user logs. Track repository contributions on contribution calendar squares.',
      btnText: 'View Analytics Graph',
      items: [
        { label: 'Contribution Grid Calendar', details: 'A github-like contribution squares grid representing commit density.' },
        { label: 'Telemetry Graphs', details: 'Line/Area charts visualising repository commit frequency over time.' },
        { label: 'Real-time Feed Logs', details: 'Feeds displaying commits, star actions, and code merge timestamps.' }
      ],
      mockup: (
        <div className="bg-github-light-bg dark:bg-github-dark-sidebar p-5 rounded-xl border border-github-light-border dark:border-github-dark-border shadow-lg space-y-3">
          <span className="text-2xs font-bold block">Contribution Frequency</span>
          <div className="flex gap-[3px] flex-wrap max-w-xs mx-auto">
            {Array.from({ length: 42 }).map((_, i) => {
              const bgClass = i % 7 === 0 ? 'bg-emerald-600' : i % 5 === 0 ? 'bg-emerald-400' : i % 3 === 0 ? 'bg-emerald-250' : 'bg-neutral-100 dark:bg-neutral-900';
              return <div key={i} className={`w-3 h-3 rounded-[1.5px] ${bgClass}`} />;
            })}
          </div>
        </div>
      )
    },
    secure: {
      title: 'Analyze central security databases',
      desc: 'Verify administrative logs and actions. Review administrative repository deletions or modifications in-memory.',
      btnText: 'Inspect Audits Logs',
      items: [
        { label: 'Administrative Audits Logs', details: 'Tables indexing actions, descriptions, IP logs, and success indicators.' },
        { label: 'Role Toggles', details: 'Ensure only validated mock sessions can execute admin dashboard controls.' },
        { label: 'Settings Security', details: 'Establish local account protection toggles and database reset points.' }
      ],
      mockup: (
        <div className="space-y-3 bg-github-light-bg dark:bg-github-dark-sidebar p-5 rounded-xl border border-github-light-border dark:border-github-dark-border shadow-lg">
          <span className="text-2xs font-bold block">Security Logs</span>
          <div className="space-y-2 text-[10px] font-mono">
            <div className="flex justify-between border-b border-github-light-border/40 dark:border-github-dark-border/40 pb-1.5">
              <span className="text-blue-500 font-bold">REPO_DELETE</span>
              <span className="text-github-light-textMuted dark:text-github-dark-textMuted">Just now</span>
            </div>
            <div className="flex justify-between border-b border-github-light-border/40 dark:border-github-dark-border/40 pb-1.5">
              <span className="text-blue-500 font-bold">COMMIT_PUSH</span>
              <span className="text-github-light-textMuted dark:text-github-dark-textMuted">2m ago</span>
            </div>
          </div>
        </div>
      )
    }
  };

  const current = contentMap[activeTab];

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.35, ease: 'easeInOut' }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center"
        >
          {/* Left Column: Descriptive text and Accordions */}
          <div className="lg:col-span-6 space-y-6">
            <div className="space-y-3">
              <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight">{current.title}</h2>
              <p className="text-sm sm:text-base text-github-light-textMuted dark:text-github-dark-textMuted leading-relaxed">{current.desc}</p>
            </div>

            {/* Accordions */}
            <div className="space-y-3 border-t border-github-light-border/40 dark:border-github-dark-border/40 pt-4">
              {current.items.map((item, index) => {
                const isOpen = openAccordion === index;
                return (
                  <div 
                    key={item.label} 
                    className="border-b border-github-light-border/40 dark:border-github-dark-border/40 pb-3"
                  >
                    <button
                      onClick={() => setOpenAccordion(isOpen ? -1 : index)}
                      className="w-full text-left font-bold text-xs sm:text-sm flex items-center justify-between py-2 cursor-pointer select-none text-github-light-text dark:text-github-dark-text"
                    >
                      <span>{item.label}</span>
                      <ChevronDown size={16} className={`text-github-light-textMuted dark:text-github-dark-textMuted transition-transform duration-300 ${
                        isOpen ? 'rotate-180 text-github-light-accent dark:text-github-dark-accent' : ''
                      }`} />
                    </button>
                    
                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.25 }}
                          className="overflow-hidden"
                        >
                          <p className="text-xs text-github-light-textMuted dark:text-github-dark-textMuted mt-1 leading-relaxed pl-1.5">
                            {item.details}
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>

            <div className="pt-2">
              <Link to="/login">
                <Button icon={ArrowRight}>
                  {current.btnText}
                </Button>
              </Link>
            </div>
          </div>

          {/* Right Column: Visual Mockup Showcase Panel */}
          <div className="lg:col-span-6 flex justify-center">
            <div className="w-full max-w-md p-6 bg-gradient-to-tr from-neutral-100 to-neutral-50 dark:from-github-dark-card dark:to-github-dark-sidebar border border-github-light-border dark:border-github-dark-border rounded-2xl shadow-premium relative overflow-hidden group">
              {/* Background accent ring */}
              <div className="absolute top-[-10%] right-[-10%] w-48 h-48 rounded-full bg-github-light-accent/5 dark:bg-github-dark-accent/5 blur-[50px] pointer-events-none" />
              
              <div className="relative z-10 transition-transform duration-500 group-hover:scale-[1.02]">
                {current.mockup}
              </div>
            </div>
          </div>

        </motion.div>
      </AnimatePresence>
    </div>
  );
}
