import React from 'react';
import CardSpotlight from './CardSpotlight';
import CardBackground from './CardBackground';
import CardGlow from './CardGlow';
import CardBorder from './CardBorder';
import CTAButton from './CTAButton';
import CardAnimation from './CardAnimation';
import CardImage from './CardImage';

export default function IndustryCard({ 
  caseKey, 
  company, 
  badge, 
  category, 
  title, 
  description, 
  isActive = false 
}) {
  
  // Custom inline premium SVG vector logos
  const renderLogo = () => {
    if (caseKey === 'figma') {
      return (
        <svg viewBox="0 0 100 150" fill="none" className="w-5 h-8 shrink-0 select-none">
          <path d="M25 25C25 11.2 36.2 0 50 0C63.8 0 75 11.2 75 25C75 38.8 63.8 50 50 50H25V25Z" fill="#F24E1E"/>
          <path d="M25 75C25 61.2 36.2 50 50 50C63.8 50 75 61.2 75 75C75 88.8 63.8 100 50 100H25V75Z" fill="#A259FF"/>
          <path d="M25 125C25 111.2 36.2 100 50 100C63.8 100 75 111.2 75 125C75 138.8 63.8 150 50 150C36.2 150 25 138.8 25 125Z" fill="#0ACF83"/>
          <circle cx="75" cy="125" r="25" fill="#1ABCFE"/>
        </svg>
      );
    }
    if (caseKey === 'mercedes') {
      return (
        <svg viewBox="0 0 100 100" stroke="#e6edf3" strokeWidth="5.5" fill="none" className="w-8 h-8 shrink-0 select-none">
          <circle cx="50" cy="50" r="41"/>
          <line x1="50" y1="50" x2="50" y2="11"/>
          <line x1="50" y1="50" x2="16" y2="70"/>
          <line x1="50" y1="50" x2="84" y2="70"/>
        </svg>
      );
    }
    return (
      <svg viewBox="0 0 100 100" fill="none" className="w-9 h-9 shrink-0 select-none">
        <path d="M20 55 C35 60 65 60 80 55" stroke="#F1C40F" strokeWidth="8.5" strokeLinecap="round"/>
        <path d="M30 40 C40 30 60 30 70 40" stroke="#3498DB" strokeWidth="6.5" strokeLinecap="round"/>
      </svg>
    );
  };

  return (
    <CardAnimation>
      <CardSpotlight className={`group flex w-full relative rounded-2xl hover:shadow-premium-hover transition-all duration-500 h-full ${
        isActive 
          ? 'md:scale-105 border-[#bc8cff]/35 shadow-[0_12px_45px_rgba(188,140,255,0.12)] z-10 scale-[1.02]' 
          : 'hover:translate-y-[-10px]'
      }`}>
        <CardBorder isActive={isActive}>
          <div className="relative w-full h-full p-8 min-h-[350px] flex flex-col justify-between overflow-hidden rounded-2xl z-10">
            <CardBackground />
            <CardImage caseKey={caseKey} />
            <CardGlow caseKey={caseKey} />
            
            {/* Top half: badge, logo, categories */}
            <div className="space-y-4 relative z-10">
              <div className="flex justify-between items-start gap-4">
                <span className="text-[9px] font-black tracking-widest text-[#8b949e] uppercase bg-[#161b22]/70 border border-[#30363d]/60 px-2.5 py-0.5 rounded-full">
                  {badge}
                </span>
                <div className="transition-transform duration-300 group-hover:scale-110">
                  {renderLogo()}
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-extrabold text-github-dark-accent tracking-widest uppercase">
                  {category}
                </span>
                <h4 className="text-base sm:text-[19px] font-black text-white leading-snug">
                  {title}
                </h4>
              </div>
            </div>

            {/* Bottom half: description, CTA trigger */}
            <div className="pt-6 relative z-10 space-y-4 border-t border-[#30363d]/45 mt-4">
              <p className="text-[11px] text-[#8b949e] font-semibold leading-relaxed">
                {description}
              </p>
              <CTAButton text={`Read ${company} Case Study`} />
            </div>

          </div>
        </CardBorder>
      </CardSpotlight>
    </CardAnimation>
  );
}
export { IndustryCard };
