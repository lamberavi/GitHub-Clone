import React from 'react';
import { motion } from 'framer-motion';

export default function Button({ 
  children, 
  onClick, 
  type = 'button',
  variant = 'primary', 
  size = 'md',
  isLoading = false,
  isDisabled = false,
  className = '',
  icon: Icon
}) {
  const baseStyle = 'inline-flex items-center justify-center font-medium rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-github-light-bg dark:focus:ring-offset-github-dark-bg disabled:opacity-50 disabled:pointer-events-none';
  
  const variants = {
    primary: 'bg-github-light-accent dark:bg-github-dark-accent text-white hover:bg-opacity-95 hover:shadow-glow focus:ring-github-light-accent/50 dark:focus:ring-github-dark-accent/50 border border-transparent',
    secondary: 'bg-neutral-100 hover:bg-neutral-200 dark:bg-github-dark-border/40 dark:hover:bg-github-dark-border text-github-light-text dark:text-github-dark-text border border-github-light-border dark:border-github-dark-border/60 focus:ring-neutral-500/50',
    outline: 'bg-transparent border border-github-light-border dark:border-github-dark-border text-github-light-text dark:text-github-dark-text hover:bg-neutral-100 dark:hover:bg-neutral-800 focus:ring-neutral-500/50',
    success: 'bg-github-light-success dark:bg-github-dark-success text-white hover:bg-opacity-95 focus:ring-github-light-success/50 dark:focus:ring-github-dark-success/50 border border-transparent',
    danger: 'bg-github-light-danger dark:bg-github-dark-danger text-white hover:bg-opacity-95 focus:ring-github-light-danger/50 dark:focus:ring-github-dark-danger/50 border border-transparent',
    ghost: 'bg-transparent text-github-light-textMuted dark:text-github-dark-textMuted hover:bg-neutral-100 dark:hover:bg-neutral-850 hover:text-github-light-text dark:hover:text-github-dark-text border border-transparent'
  };

  const sizes = {
    sm: 'px-2.5 py-1.5 text-xs gap-1.5',
    md: 'px-4 py-2 text-sm gap-2',
    lg: 'px-5 py-2.5 text-base gap-2.5'
  };

  return (
    <motion.button
      whileTap={{ scale: isDisabled || isLoading ? 1 : 0.98 }}
      type={type}
      onClick={onClick}
      disabled={isDisabled || isLoading}
      className={`${baseStyle} ${variants[variant]} ${sizes[size]} ${className}`}
    >
      {isLoading && (
        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-current" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
        </svg>
      )}
      {!isLoading && Icon && <Icon size={size === 'sm' ? 14 : size === 'lg' ? 20 : 16} className="shrink-0" />}
      <span>{children}</span>
    </motion.button>
  );
}
